CREATE OR REPLACE FUNCTION calculate_and_submit_exam(
    p_exam_code TEXT,
    p_student_id TEXT,
    p_student_name TEXT,
    p_class_name TEXT,
    p_school_name TEXT,
    p_answers JSONB,
    p_status TEXT,
    p_device_info JSONB,
    p_location JSONB,
    p_activity_log JSONB,
    p_result_id UUID DEFAULT NULL
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_exam RECORD;
    v_score NUMERIC := 0;
    v_total_questions NUMERIC := 0;
    v_correct_answers NUMERIC := 0;
    v_question JSONB;
    v_student_answer TEXT;
    v_correct_answer TEXT;
    v_q_type TEXT;
    v_weight NUMERIC;
    v_is_correct BOOLEAN;
    v_result_id UUID := p_result_id;
    v_existing_answers JSONB := '{}'::jsonb;
    v_merged_answers JSONB := COALESCE(p_answers, '{}'::jsonb);
    v_existing_log JSONB := '[]'::jsonb;
    v_merged_log JSONB;
    v_existing_status TEXT;
    v_manual_grade TEXT;
    v_return_record RECORD;
BEGIN
    -- 1. Fetch Exam
    SELECT * INTO v_exam FROM exams WHERE code = p_exam_code;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Exam not found';
    END IF;

    -- 2. Fetch existing result if any
    IF v_result_id IS NOT NULL THEN
        SELECT answers, status, activity_log INTO v_existing_answers, v_existing_status, v_existing_log
        FROM results WHERE id = v_result_id;
        
        IF v_existing_status IN ('completed', 'force_closed') AND p_status = 'in_progress' THEN
            -- Ignore update if already finished and this is just auto-save
            SELECT * INTO v_return_record FROM results WHERE id = v_result_id;
            RETURN row_to_json(v_return_record)::jsonb;
        END IF;
    ELSE
        -- Might exist by exam_code + student_id
        SELECT id, answers, status, activity_log INTO v_result_id, v_existing_answers, v_existing_status, v_existing_log
        FROM results WHERE exam_code = p_exam_code AND student_id = p_student_id LIMIT 1;
    END IF;

    -- Merge activity_log (unique items) - keeping it simple by coalescing
    IF v_existing_log IS NULL THEN v_existing_log := '[]'::jsonb; END IF;
    IF p_activity_log IS NULL THEN p_activity_log := '[]'::jsonb; END IF;
    v_merged_log := p_activity_log;

    -- Merge manual grades from existing answers to new answers
    IF v_existing_answers IS NOT NULL THEN
        FOR v_question IN SELECT * FROM jsonb_each(v_existing_answers)
        LOOP
            IF v_question.key LIKE '\_grade\_%' THEN
                v_merged_answers := jsonb_set(v_merged_answers, ARRAY[v_question.key], v_question.value);
            END IF;
        END LOOP;
    END IF;

    -- 3. Calculate Score using simple logic
    FOR v_question IN SELECT * FROM jsonb_array_elements(v_exam.questions)
    LOOP
        v_q_type := v_question->>'questionType';
        
        IF v_q_type = 'INFO' THEN
            CONTINUE;
        END IF;

        v_weight := COALESCE((v_question->>'scoreWeight')::numeric, 1);
        v_total_questions := v_total_questions + v_weight;

        v_student_answer := v_merged_answers->>(v_question->>'id');
        v_correct_answer := v_question->>'correctAnswer';
        
        -- Check manual grade first
        v_manual_grade := v_merged_answers->>('_grade_' || (v_question->>'id'));
        IF v_manual_grade IS NOT NULL THEN
            IF v_manual_grade = 'CORRECT' THEN
                v_correct_answers := v_correct_answers + 1;
                v_score := v_score + v_weight;
            END IF;
            CONTINUE;
        END IF;

        IF v_student_answer IS NULL OR v_student_answer = '' THEN
            CONTINUE;
        END IF;

        v_is_correct := false;

        IF v_q_type IN ('MULTIPLE_CHOICE', 'FILL_IN_THE_BLANK') THEN
            -- Removing html and spaces, taking pure alphanumeric
            IF regexp_replace(lower(v_student_answer), '[^a-z0-9]', '', 'g') = regexp_replace(lower(v_correct_answer), '[^a-z0-9]', '', 'g') THEN
                v_is_correct := true;
            END IF;
        ELSE
            -- basic string equality for others or teacher can manual grade
            IF v_student_answer = v_correct_answer THEN
                v_is_correct := true;
            END IF;
        END IF;

        IF v_is_correct THEN
            v_correct_answers := v_correct_answers + 1;
            v_score := v_score + v_weight;
        END IF;
    END LOOP;

    -- 4. Upsert Result
    IF v_result_id IS NOT NULL THEN
        UPDATE results SET
            answers = v_merged_answers,
            status = p_status,
            activity_log = v_merged_log,
            score = v_score,
            correct_answers = v_correct_answers,
            total_questions = v_total_questions,
            location = COALESCE(p_location, location),
            device_info = COALESCE(p_device_info, device_info),
            updated_at = NOW()
        WHERE id = v_result_id
        RETURNING * INTO v_return_record;
    ELSE
        INSERT INTO results (
            exam_code, student_id, student_name, class_name, location,
            answers, status, score, correct_answers, total_questions, activity_log, device_info
        ) VALUES (
            p_exam_code, p_student_id, p_student_name, COALESCE(p_school_name || '::' || p_class_name, p_class_name), p_location,
            v_merged_answers, p_status, v_score, v_correct_answers, v_total_questions, v_merged_log, p_device_info
        ) RETURNING * INTO v_return_record;
    END IF;

    RETURN row_to_json(v_return_record)::jsonb;
END;
$$;
