const deepParse = (input) => {
    try {
        let fixedInput = input;
        try {
            JSON.parse(fixedInput);
        } catch (e) {
            fixedInput = input.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t");
        }
        const parsed = JSON.parse(fixedInput);
        if (typeof parsed === 'string') {
            return deepParse(parsed);
        }
        return parsed;
    } catch (e) {
        let cleaned = input.trim();
        if (cleaned.startsWith('[') && !cleaned.endsWith(']')) cleaned = cleaned.slice(1);
        if (cleaned.endsWith(']') && !cleaned.startsWith('[')) cleaned = cleaned.slice(0, -1);
        if (cleaned.startsWith('"') && cleaned.endsWith('"')) cleaned = cleaned.slice(1, -1);
        cleaned = cleaned.replace(/\\"/g, '"');
        return cleaned;
    }
};

const str = `["0,5","50%"," \n2\n4\n42​ \n"]`;
console.log(deepParse(str));
