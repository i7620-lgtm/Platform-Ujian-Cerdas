import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  ArrowLeftIcon,
  UserIcon,
  QrCodeIcon,
  CheckCircleIcon,
  LockClosedIcon,
  SunIcon,
  MoonIcon,
  ChevronDownIcon,
  XMarkIcon,
} from "../Icons";
import type { Student } from "../../types";
import { storageService } from "../../services/storage";
import { supabase } from "../../lib/supabase";

interface StudentEntryFormProps {
  onLoginSuccess: (examCode: string, student: Student) => void;
  onBack: () => void;
  isDarkMode?: boolean;
  toggleTheme?: () => void;
  initialCode?: string;
}

// Helper to parse "SchoolName-ClassName(Limit)" format
const parseClassConfig = (classString: string) => {
  const match = classString.match(/^(.+?)(?:\((\d+)\))?$/);
  if (match) {
    const fullString = match[1].trim();
    const limit = match[2] ? parseInt(match[2], 10) : null;

    let schoolName = "";
    let className = fullString;

    const dashIndex = fullString.indexOf("-");
    if (dashIndex !== -1) {
      schoolName = fullString.substring(0, dashIndex).trim();
      className = fullString.substring(dashIndex + 1).trim();
    }

    return {
      schoolName,
      name: className,
      limit,
    };
  }
  return { schoolName: "", name: classString, limit: null };
};

const QrScannerModal: React.FC<{
  onScanSuccess: (text: string) => void;
  onClose: () => void;
}> = ({ onScanSuccess, onClose }) => {
  const scannerRef = useRef<any>(null);

  useEffect(() => {
    let isMounted = true;

    const initScanner = async () => {
      try {
        // Load from CDN to avoid build-time resolution issues with the package
        if (!(window as any).Html5Qrcode) {
          await new Promise((resolve, reject) => {
            const script = document.createElement("script");
            script.src =
              "https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js";
            script.async = true;
            script.onload = resolve;
            script.onerror = () =>
              reject(new Error("Failed to load QR scanner script"));
            document.body.appendChild(script);
          });
        }

        if (!isMounted) return;

        // Access global variable
        const Html5Qrcode = (window as any).Html5Qrcode as new (
          id: string,
          verbose: boolean,
        ) => {
          start: (
            config: any,
            options: any,
            onSuccess: (text: string) => void,
            onError: (error: any) => void,
          ) => Promise<void>;
          stop: () => Promise<void>;
          clear: () => void;
        };
        if (!Html5Qrcode) throw new Error("Html5Qrcode not found");

        const html5QrCode = new Html5Qrcode("reader-entry", false);
        scannerRef.current = html5QrCode;

        const config = { fps: 10 };

        await html5QrCode.start(
          { facingMode: "environment" },
          config,
          (decodedText: string) => {
            if (isMounted) onScanSuccess(decodedText);
          },
          () => {
            // ignore parse errors
          },
        );
      } catch (err) {
        console.error("Error starting scanner", err);
        if (isMounted) {
          alert(
            "Gagal memuat pemindai kamera. Pastikan koneksi internet stabil.",
          );
          onClose();
        }
      }
    };

    const timer = setTimeout(initScanner, 100);

    return () => {
      isMounted = false;
      clearTimeout(timer);
      if (scannerRef.current) {
        const scanner = scannerRef.current as {
          stop: () => Promise<void>;
          clear: () => void;
        };
        scanner
          .stop()
          .then(() => {
            try {
              scanner.clear();
            } catch {
              /* ignore */
            }
          })
          .catch((e: any) => console.log("Stop failed", e));
      }
    };
  }, [onClose, onScanSuccess]);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-fade-in">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-2xl w-full max-w-sm relative animate-slide-in-up border border-white dark:border-slate-700">
        <h3 className="text-center font-black text-slate-800 dark:text-white mb-4 text-lg">
          Pindai QR Code Ujian
        </h3>
        <div className="relative rounded-2xl overflow-hidden bg-black aspect-square shadow-inner">
          <div id="reader-entry" className="w-full h-full"></div>
          {/* Scanning Line Animation */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="w-full h-0.5 bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,1)] animate-[scan_2s_ease-in-out_infinite]"></div>
            <style>{`
                             @keyframes scan {
                                 0% { transform: translateY(0); opacity: 0; }
                                 10% { opacity: 1; }
                                 90% { opacity: 1; }
                                 100% { transform: translateY(100%); opacity: 0; }
                             }
                         `}</style>
          </div>
        </div>
        <p className="text-xs text-center text-slate-500 dark:text-slate-400 mt-4 font-medium">
          Arahkan kamera ke QR Code ujian.
          <br />
          Pastikan cahaya cukup terang.
        </p>
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors"
        >
          <XMarkIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

const UnlockForm: React.FC<{
  onUnlock: (token: string) => void;
  onCancel: () => void;
}> = ({ onUnlock, onCancel }) => {
  const [token, setToken] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onUnlock(token);
      }}
      className="space-y-3"
    >
      <input
        type="text"
        value={token}
        onChange={(e) => setToken(e.target.value)}
        className="w-full text-center text-xl font-mono font-black tracking-[0.3em] py-3 bg-slate-50 dark:bg-slate-950 border-2 border-slate-200 dark:border-slate-800 rounded-xl focus:border-rose-400 dark:focus:border-rose-500 focus:bg-white dark:focus:bg-slate-900 outline-none uppercase transition-all text-slate-900 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-700"
        placeholder="TOKEN"
        maxLength={6}
      />
      <div className="flex gap-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 py-3 text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors uppercase tracking-wide"
        >
          Batal
        </button>
        <button
          type="submit"
          className="flex-[2] py-3 text-xs font-bold text-white bg-rose-500 rounded-xl hover:bg-rose-600 shadow-lg shadow-rose-200 dark:shadow-rose-900/30 transition-all uppercase tracking-wide"
        >
          Buka Akses
        </button>
      </div>
    </form>
  );
};

export const StudentEntryForm: React.FC<StudentEntryFormProps> = ({
  onLoginSuccess,
  onBack,
  isDarkMode,
  toggleTheme,
  initialCode,
}) => {
  // Logic State
  const [isLoading, setIsLoading] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [availableClasses, setAvailableClasses] = useState<string[]>([]);
  const [registeredData, setRegisteredData] = useState<any[]>([]);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [pendingStudentData, setPendingStudentData] = useState<{
    cleanExamCode: string;
    studentData: Student;
  } | null>(null);

  // UI State
  const [examCode, setExamCode] = useState(initialCode || "");
  const [fullName, setFullName] = useState("");
  const [schoolName, setSchoolName] = useState("");
  const [studentClass, setStudentClass] = useState("");
  const [absentNumber, setAbsentNumber] = useState("");
  const [isCheckingCode, setIsCheckingCode] = useState(false);

  const [error, setError] = useState("");
  const [isFocused, setIsFocused] = useState<string | null>(null);
  const examCodeInputRef = useRef<HTMLInputElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  // Derived state for absent/NIS limit
  const { limit: absentLimit } = parseClassConfig(studentClass);

  const availableSchools = useMemo(() => {
    if (registeredData.length > 0) {
      return Array.from(
        new Set(registeredData.map((r) => r.school_name).filter(Boolean)),
      );
    }
    const schools = new Set<string>();
    availableClasses.forEach((c) => {
      const parsed = parseClassConfig(c);
      if (parsed.schoolName) schools.add(parsed.schoolName);
    });
    return Array.from(schools);
  }, [availableClasses, registeredData]);

  const filteredClasses = useMemo(() => {
    if (registeredData.length > 0) {
      if (!schoolName) return [];
      return Array.from(
        new Set(
          registeredData
            .filter((r) => r.school_name === schoolName)
            .map((r) => r.class_name)
            .filter(Boolean),
        ),
      );
    }
    if (!schoolName) return availableClasses;
    return availableClasses.filter((c) => {
      const parsed = parseClassConfig(c);
      return !parsed.schoolName || parsed.schoolName === schoolName;
    });
  }, [availableClasses, schoolName, registeredData]);

  const filteredStudents = useMemo(() => {
    if (registeredData.length > 0 && schoolName && studentClass) {
      return registeredData.filter(
        (r) =>
          r.school_name === schoolName &&
          r.class_name === studentClass &&
          r.student_name,
      );
    }
    return [];
  }, [registeredData, schoolName, studentClass]);

  // Auto-fetch config and load scoped student data when code changes
  useEffect(() => {
    let isMounted = true;
    const checkConfig = async () => {
      const cleanCode = examCode.toUpperCase().trim();
      if (cleanCode.length === 6) {
        setIsCheckingCode(true);
        // Load scoped student data for this specific exam code
        try {
          const scopedData = localStorage.getItem(`student_pref_${cleanCode}`);
          if (scopedData && isMounted) {
            const parsed = JSON.parse(scopedData);
            if (parsed.fullName) setFullName(parsed.fullName);
            if (parsed.schoolName) setSchoolName(parsed.schoolName);
            if (parsed.studentClass) setStudentClass(parsed.studentClass);
            if (parsed.absentNumber) setAbsentNumber(parsed.absentNumber);
          }
        } catch {
          /* ignore */
        }

        try {
          const config = await storageService.getExamConfig(cleanCode);

          const { data: regData } = await supabase
            .from("registered_students")
            .select("*")
            .eq("exam_code", cleanCode);

          if (!isMounted) return;

          if (regData && regData.length > 0) {
            setRegisteredData(regData);
            const schools = Array.from(
              new Set(regData.map((r) => r.school_name).filter(Boolean)),
            );
            if (schools.length === 1) {
              setSchoolName(schools[0]);
            } else if (schools.length > 1) {
              setSchoolName((prev) => (schools.includes(prev) ? prev : ""));
            }
          } else {
            setRegisteredData([]);
          }

          if (
            config &&
            config.targetClasses &&
            config.targetClasses.length > 0
          ) {
            setAvailableClasses(config.targetClasses);
            setStudentClass((prev) => {
              if (prev && !config.targetClasses?.includes(prev)) return "";
              return prev;
            });

            if (!regData || regData.length === 0) {
              const schools = new Set<string>();
              config.targetClasses.forEach((c) => {
                const parsed = parseClassConfig(c);
                if (parsed.schoolName) schools.add(parsed.schoolName);
              });
              if (schools.size === 1) {
                setSchoolName(Array.from(schools)[0]);
              } else if (schools.size > 1) {
                setSchoolName((prev) => (schools.has(prev) ? prev : ""));
              }
            }
          } else {
            setAvailableClasses([]);
          }
        } catch (err) {
          console.error("Error fetching config", err);
        } finally {
          if (isMounted) setIsCheckingCode(false);
        }
      } else {
        if (isMounted) {
          setAvailableClasses([]);
          setRegisteredData([]);
          setIsCheckingCode(false);
        }
      }
    };
    checkConfig();
    return () => {
      isMounted = false;
    };
  }, [examCode]);

  useEffect(() => {
    // Logic fokus kursor cerdas
    if (initialCode) {
      const t = setTimeout(() => nameInputRef.current?.focus(), 100);
      return () => clearTimeout(t);
    } else {
      let savedName, savedClass, savedAbsent;
      try {
        savedName = localStorage.getItem("saved_student_fullname");
        savedClass = localStorage.getItem("saved_student_class");
        savedAbsent = localStorage.getItem("saved_student_absent");
      } catch {
        /* ignore */
      }

      if (savedName && savedClass && savedAbsent && examCodeInputRef.current) {
        examCodeInputRef.current.focus();
      }
    }
  }, [initialCode]);

  const normalizeId = (text: string) => {
    return text.trim().toLowerCase().replace(/\s+/g, "");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (
      !examCode ||
      !fullName ||
      !schoolName ||
      !studentClass ||
      !absentNumber
    ) {
      setError("Mohon lengkapi semua data identitas.");
      return;
    }

    const cleanExamCode = examCode.toUpperCase().trim();
    let examConfig = null;

    if (cleanExamCode.length === 6) {
      try {
        examConfig = await storageService.getExamConfig(cleanExamCode);

        const validSchools =
          registeredData.length > 0
            ? Array.from(
                new Set(
                  registeredData.map((r) => r.school_name).filter(Boolean),
                ),
              )
            : examConfig?.targetClasses
              ? Array.from(
                  new Set(
                    examConfig.targetClasses
                      .map((c) => parseClassConfig(c).schoolName)
                      .filter(Boolean),
                  ),
                )
              : [];

        if (
          validSchools.length > 0 &&
          !validSchools.includes(schoolName.trim())
        ) {
          setError(
            "Asal Sekolah tidak valid. Harap pilih dari daftar sekolah yang tersedia.",
          );
          setSchoolName("");
          setIsLoading(false);
          return;
        }

        const validClasses =
          registeredData.length > 0
            ? Array.from(
                new Set(
                  registeredData.map((r) => r.class_name).filter(Boolean),
                ),
              )
            : examConfig?.targetClasses;

        if (
          validClasses &&
          validClasses.length > 0 &&
          !validClasses.includes(studentClass.trim())
        ) {
          setError(
            "Kelas tidak valid. Harap pilih dari daftar kelas yang tersedia.",
          );
          setStudentClass("");
          setIsLoading(false);
          return;
        }

        if (!registeredData.length) {
          const { limit } = parseClassConfig(studentClass.trim());
          if (limit && limit > 0) {
            const num = parseInt(absentNumber, 10);
            if (
              isNaN(num) ||
              num < 1 ||
              num > limit ||
              num.toString() !== absentNumber.trim()
            ) {
              setError(
                `No. Absen/NIS tidak valid. Harap pilih antara 1 hingga ${limit}.`,
              );
              setAbsentNumber("");
              setIsLoading(false);
              return;
            }
          }
        }
      } catch {
        // Offline fallback is fine
      }
    }

    if (examConfig) {
      if (examConfig.isFinished) {
        setError("Ujian ini telah dihentikan oleh Guru.");
        setIsLoading(false);
        return;
      }

      const now = new Date();
      const mode = examConfig.examMode || "UJIAN";

      if (mode === "UJIAN") {
        const startDateStr = examConfig.startDate || examConfig.date;
        if (startDateStr) {
          let startDateTime: Date;
          if (startDateStr.includes("T") && startDateStr.length > 10) {
            startDateTime = new Date(startDateStr);
          } else {
            startDateTime = new Date(
              `${startDateStr}T${examConfig.startTime || "00:00"}`,
            );
          }

          // Allow entering up to WAITING_ROOM if not started yet
          if (now < startDateTime) {
            // Let the parent direct to the waiting room!
          }
        }
        const getLocalDateStr = (raw: string) => {
          if (!raw) return "";
          if (raw.includes("T")) {
            const d = new Date(raw);
            return isNaN(d.getTime()) ? "" : d.toLocaleDateString("en-CA");
          }
          return raw;
        };

        const endDateStr = getLocalDateStr(
          examConfig.endDate || examConfig.date,
        );
        const endTimeStr = examConfig.endTime || "23:59";
        let endDateTime: Date;
        if (examConfig.endDate && examConfig.endDate.includes("T")) {
          endDateTime = new Date(examConfig.endDate);
        } else {
          endDateTime = new Date(`${endDateStr}T${endTimeStr}:59`);
        }

        if (!isNaN(endDateTime.getTime()) && now > endDateTime) {
          setError(
            `Ujian telah berakhir pada ${endDateTime.toLocaleString("id-ID")}`,
          );
          setIsLoading(false);
          return;
        }
      } else if (mode === "PR") {
        const fallbackDateStr = examConfig.endDate || examConfig.date;
        if (fallbackDateStr) {
          const datePart = fallbackDateStr.includes("T")
            ? fallbackDateStr.split("T")[0]
            : fallbackDateStr;
          const endDateTime = new Date(`${datePart}T23:59:59`);
          if (now > endDateTime) {
            setError(
              `Batas waktu pengerjaan PR telah berakhir pada ${endDateTime.toLocaleString("id-ID")}`,
            );
            setIsLoading(false);
            return;
          }
        }
      }
    }

    setError("");

    // Save preferences
    try {
      const prefData = {
        fullName: fullName.trim(),
        schoolName: schoolName.trim(),
        studentClass: studentClass.trim(),
        absentNumber: absentNumber.trim(),
      };
      localStorage.setItem(
        `student_pref_${cleanExamCode}`,
        JSON.stringify(prefData),
      );

      localStorage.setItem("saved_student_fullname", fullName.trim());
      localStorage.setItem("saved_student_school", schoolName.trim());
      localStorage.setItem("saved_student_class", studentClass.trim());
      localStorage.setItem("saved_student_absent", absentNumber.trim());
    } catch {
      /* ignore */
    }

    const { name: cleanClassName } = parseClassConfig(studentClass);

    const normClass = normalizeId(cleanClassName);
    const normAbsent = normalizeId(absentNumber);
    const seatId = `${normClass}-${normAbsent}`;

    const cleanSchool = schoolName.trim();
    const cleanName = fullName.trim();
    const cleanClass = cleanClassName.trim();
    const cleanAbs = absentNumber.trim();
    const compositeId = `@${cleanSchool}#${cleanName}$${cleanClass}%${cleanAbs}`;

    const studentData: Student = {
      fullName: cleanName,
      schoolName: cleanSchool,
      class: cleanClass,
      absentNumber: cleanAbs,
      studentId: compositeId,
    };

    setIsLoading(true);

    try {
      const localKey = `exam_local_${cleanExamCode}_${seatId}`;
      const hasLocalData = await storageService.getLocalProgress(localKey);

      const allResults = await storageService.getResults(cleanExamCode);
      const normSchool = normalizeId(schoolName);
      const remoteResult = allResults.find(
        (r) =>
          normalizeId(r.student.schoolName || "") === normSchool &&
          normalizeId(r.student.class) === normClass &&
          normalizeId(r.student.absentNumber) === normAbsent,
      );

      if (remoteResult) {
        const storedName = normalizeId(remoteResult.student.fullName);
        const inputName = normalizeId(fullName);

        const isNameMatch =
          storedName === inputName ||
          storedName.includes(inputName) ||
          inputName.includes(storedName);

        if (!isNameMatch) {
          setError(
            `Sudah ada orang lain yang menggunakan kelas dan absen tersebut (dengan nama: ${remoteResult.student.fullName}, kelas: ${remoteResult.student.class}, dan absen: ${remoteResult.student.absentNumber}).`,
          );
          setIsLoading(false);
          return;
        }

        studentData.studentId = remoteResult.student.studentId;

        if (remoteResult.status === "completed") {
          if (examConfig && examConfig.allowRetakes) {
            try {
              await storageService.deleteStudentResult(
                cleanExamCode,
                remoteResult.student.studentId,
              );
              const localKey = `exam_local_${cleanExamCode}_${seatId}`;
              await storageService.clearLocalProgress(localKey);
            } catch (err) {
              console.error(
                "Gagal menghapus data lama untuk kerjakan ulang:",
                err,
              );
            }
          } else {
            setError(
              "Anda sudah menyelesaikan ujian ini dan tidak dapat mengulang kembali.",
            );
            setIsLoading(false);
            return;
          }
        } else if (remoteResult.status === "force_closed") {
          setIsLocked(true);
          setIsLoading(false);
          return;
        } else if (remoteResult.status === "in_progress" && !hasLocalData) {
          if (examConfig && examConfig.continueWithPermission) {
            setIsLocked(true);
            setIsLoading(false);
            return;
          }
        }
      }

      setPendingStudentData({ cleanExamCode, studentData });
    } catch (e) {
      console.error("Session check error", e);
      setError("Gagal memeriksa sesi ujian. Periksa koneksi internet.");
      setIsLoading(false);
    }
  };

  const handleUnlockAndResume = async (token: string) => {
    const cleanExamCode = examCode.toUpperCase().trim();
    const { name: cleanClassName } = parseClassConfig(studentClass);

    const normClass = normalizeId(cleanClassName);
    const normAbsent = normalizeId(absentNumber);

    const cleanSchool = schoolName.trim();
    const cleanName = fullName.trim();
    const cleanClass = cleanClassName.trim();
    const cleanAbs = absentNumber.trim();
    let compositeId = `@${cleanSchool}#${cleanName}$${cleanClass}%${cleanAbs}`;

    try {
      const allResults = await storageService.getResults(cleanExamCode);
      const normSchool = normalizeId(schoolName);
      const remoteResult = allResults.find(
        (r) =>
          normalizeId(r.student.schoolName || "") === normSchool &&
          normalizeId(r.student.class) === normClass &&
          normalizeId(r.student.absentNumber) === normAbsent,
      );

      if (remoteResult) {
        compositeId = remoteResult.student.studentId;
      }

      const verified = await storageService.verifyUnlockToken(
        cleanExamCode,
        compositeId,
        token,
      );
      if (verified) {
        const studentData: Student = {
          fullName: cleanName,
          schoolName: cleanSchool,
          class: cleanClass,
          absentNumber: cleanAbs,
          studentId: compositeId,
        };
        setIsLocked(false);
        onLoginSuccess(cleanExamCode, studentData);
      } else {
        alert("Token salah.");
      }
    } catch {
      alert("Gagal verifikasi token.");
    }
  };

  if (isLocked) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-[#FAFAFA] dark:bg-slate-950 relative font-sans transition-colors duration-300">
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-gradient-to-br from-rose-50/60 to-orange-50/60 dark:from-rose-900/20 dark:to-orange-900/20 rounded-full blur-[100px] animate-pulse"></div>
        </div>
        <div className="w-full max-w-[420px] px-4 relative z-10 py-10 my-auto">
          <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-6 sm:p-8 rounded-[2rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.03)] dark:shadow-none border border-white dark:border-slate-800 ring-1 ring-slate-50 dark:ring-slate-800 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-rose-50 dark:bg-rose-900/30 text-rose-500 dark:text-rose-400 rounded-full mb-4 ring-8 ring-rose-50/50 dark:ring-rose-900/20">
              <LockClosedIcon className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-black text-slate-800 dark:text-white mb-2 tracking-tight">
              Sesi Terkunci
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
              Akun "{fullName}" (Kelas {studentClass}, No {absentNumber}) sedang
              aktif atau dihentikan paksa.
              <br />
              Masukkan <strong>Token Reset</strong> dari pengawas.
            </p>
            <UnlockForm
              onUnlock={handleUnlockAndResume}
              onCancel={() => {
                setIsLocked(false);
                setIsLoading(false);
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-[#FAFAFA] dark:bg-slate-950 relative font-sans selection:bg-indigo-100 selection:text-indigo-800 transition-colors duration-300">
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-gradient-to-br from-indigo-50/60 to-purple-50/60 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "8s" }}
        ></div>
        <div
          className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-gradient-to-tl from-blue-50/60 to-emerald-50/60 dark:from-blue-900/20 dark:to-emerald-900/20 rounded-full blur-[100px] animate-pulse"
          style={{ animationDuration: "10s" }}
        ></div>
      </div>

      {toggleTheme && (
        <div className="absolute top-6 right-6 z-50">
          <button
            onClick={toggleTheme}
            className="p-2.5 rounded-full bg-white/50 dark:bg-slate-800/50 backdrop-blur-md text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all shadow-sm border border-white/20 dark:border-slate-700"
          >
            {isDarkMode ? (
              <SunIcon className="w-5 h-5" />
            ) : (
              <MoonIcon className="w-5 h-5" />
            )}
          </button>
        </div>
      )}

      <div className="w-full max-w-[420px] px-4 relative z-10 flex flex-col sm:h-auto justify-center py-10 my-auto animate-gentle-slide">
        <button
          onClick={onBack}
          className="group self-start flex items-center gap-2 text-slate-400 dark:text-slate-500 hover:text-slate-800 dark:hover:text-slate-300 mb-4 text-[10px] font-bold uppercase tracking-widest transition-all pl-2 py-2"
        >
          <div className="w-6 h-6 rounded-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
            <ArrowLeftIcon className="w-3 h-3" />
          </div>
          <span>Kembali</span>
        </button>

        <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl p-6 sm:p-8 rounded-[2rem] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.03)] dark:shadow-black/20 border border-white dark:border-slate-800 ring-1 ring-slate-50 dark:ring-slate-800">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 shadow-[0_10px_20px_-5px_rgba(79,70,229,0.15)] dark:shadow-none mb-3 text-indigo-600 dark:text-indigo-400 border border-indigo-50 dark:border-slate-700 relative overflow-hidden">
              <div className="absolute inset-0 bg-indigo-50/50 dark:bg-indigo-900/20 rounded-2xl transform rotate-45 translate-y-6 translate-x-6"></div>
              <UserIcon className="w-6 h-6 relative z-10" />
            </div>
            <h2 className="text-xl font-black text-slate-800 dark:text-white tracking-tight">
              Selamat Datang
            </h2>
            <p className="text-slate-400 dark:text-slate-500 text-xs font-medium mt-1">
              Siapkan diri untuk ujian hari ini.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-3">
              <div
                className={`transition-all duration-300 rounded-xl bg-slate-50 dark:bg-slate-950 border ${isFocused === "school" ? "bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-500 shadow-[0_4px_20px_-4px_rgba(79,70,229,0.1)] ring-4 ring-indigo-500/5 dark:ring-indigo-500/20" : "border-transparent dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900"}`}
              >
                <div className="px-4 pt-2">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-0.5">
                    Asal Sekolah
                  </label>
                  {availableSchools.length > 0 ? (
                    <div className="relative group">
                      <select
                        value={schoolName}
                        onChange={(e) => {
                          setSchoolName(e.target.value);
                          setStudentClass("");
                        }}
                        onFocus={() => setIsFocused("school")}
                        onBlur={() => setIsFocused(null)}
                        className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 focus:ring-0 outline-none appearance-none cursor-pointer"
                        required
                      >
                        <option value="" disabled className="dark:bg-slate-900">
                          Pilih Sekolah...
                        </option>
                        {availableSchools.map((s) => (
                          <option
                            key={s}
                            value={s}
                            className="dark:bg-slate-900"
                          >
                            {s}
                          </option>
                        ))}
                      </select>
                      <div className="absolute right-0 top-0 text-slate-400 pointer-events-none">
                        <ChevronDownIcon className="w-4 h-4" />
                      </div>
                    </div>
                  ) : (
                    <input
                      type="text"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      onFocus={() => setIsFocused("school")}
                      onBlur={() => setIsFocused(null)}
                      className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:ring-0 outline-none"
                      placeholder="Nama sekolah..."
                      required
                    />
                  )}
                </div>
              </div>

              <div
                className={`transition-all duration-300 rounded-xl bg-slate-50 dark:bg-slate-950 border ${isFocused === "name" ? "bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-500 shadow-[0_4px_20px_-4px_rgba(79,70,229,0.1)] ring-4 ring-indigo-500/5 dark:ring-indigo-500/20" : "border-transparent dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900"}`}
              >
                <div className="px-4 pt-2">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-0.5">
                    Nama Lengkap
                  </label>
                  {filteredStudents.length > 0 ? (
                    <div className="relative group">
                      <select
                        value={fullName}
                        onChange={(e) => {
                          const selectedName = e.target.value;
                          setFullName(selectedName);
                          const student = filteredStudents.find(
                            (s) => s.student_name === selectedName,
                          );
                          if (student && student.absent_number) {
                            setAbsentNumber(student.absent_number);
                          }
                        }}
                        onFocus={() => setIsFocused("name")}
                        onBlur={() => setIsFocused(null)}
                        className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 focus:ring-0 outline-none appearance-none cursor-pointer"
                        required
                      >
                        <option value="" disabled className="dark:bg-slate-900">
                          Pilih Nama...
                        </option>
                        {filteredStudents.map((s) => (
                          <option
                            key={s.id}
                            value={s.student_name}
                            className="dark:bg-slate-900"
                          >
                            {s.student_name}
                          </option>
                        ))}
                      </select>
                      <div className="absolute right-0 top-0 text-slate-400 pointer-events-none">
                        <ChevronDownIcon className="w-4 h-4" />
                      </div>
                    </div>
                  ) : (
                    <input
                      ref={nameInputRef}
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      onFocus={() => setIsFocused("name")}
                      onBlur={() => setIsFocused(null)}
                      className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:ring-0 outline-none"
                      placeholder="Ketik nama anda..."
                      required
                    />
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div
                  className={`transition-all duration-300 rounded-xl bg-slate-50 dark:bg-slate-950 border ${isFocused === "class" ? "bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-500 shadow-[0_4px_20px_-4px_rgba(79,70,229,0.1)] ring-4 ring-indigo-500/5 dark:ring-indigo-500/20" : "border-transparent dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900"}`}
                >
                  <div className="px-4 pt-2">
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-0.5">
                      Kelas
                    </label>

                    {availableClasses.length > 0 ||
                    registeredData.length > 0 ? (
                      <div className="relative group">
                        <select
                          value={studentClass}
                          onChange={(e) => {
                            const val = e.target.value;
                            setStudentClass(val);
                            setFullName("");
                            setAbsentNumber("");
                            const parsed = parseClassConfig(val);
                            if (parsed.schoolName && !schoolName) {
                              setSchoolName(parsed.schoolName);
                            }
                          }}
                          onFocus={() => setIsFocused("class")}
                          onBlur={() => setIsFocused(null)}
                          className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 focus:ring-0 outline-none appearance-none cursor-pointer"
                          required
                        >
                          <option
                            value=""
                            disabled
                            className="dark:bg-slate-900"
                          >
                            Pilih...
                          </option>
                          {filteredClasses.map((c) => {
                            const { schoolName: sName, name } =
                              parseClassConfig(c);
                            const displayName =
                              sName && !schoolName
                                ? `${sName} - ${name}`
                                : name;
                            return (
                              <option
                                key={c}
                                value={c}
                                className="dark:bg-slate-900"
                              >
                                {displayName}
                              </option>
                            );
                          })}
                        </select>
                        <div className="absolute right-0 top-0 text-slate-400 pointer-events-none">
                          <ChevronDownIcon className="w-4 h-4" />
                        </div>
                      </div>
                    ) : (
                      <input
                        type="text"
                        value={studentClass}
                        onChange={(e) => setStudentClass(e.target.value)}
                        onFocus={() => setIsFocused("class")}
                        onBlur={() => setIsFocused(null)}
                        className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:ring-0 outline-none"
                        placeholder="Contoh: 9A"
                        required
                      />
                    )}
                  </div>
                </div>

                <div
                  className={`transition-all duration-300 rounded-xl bg-slate-50 dark:bg-slate-950 border ${isFocused === "absent" ? "bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-500 shadow-[0_4px_20px_-4px_rgba(79,70,229,0.1)] ring-4 ring-indigo-500/5 dark:ring-indigo-500/20" : "border-transparent dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-900"}`}
                >
                  <div className="px-4 pt-2">
                    <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-0.5 font-sans leading-none">
                      No. Absen / NIS
                    </label>
                    {filteredStudents.length > 0 ? (
                      <input
                        type="text"
                        value={absentNumber}
                        readOnly
                        className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 focus:ring-0 outline-none text-center cursor-not-allowed opacity-70"
                        placeholder="-"
                      />
                    ) : absentLimit && absentLimit > 0 ? (
                      <div className="relative group">
                        <select
                          value={absentNumber}
                          onChange={(e) => setAbsentNumber(e.target.value)}
                          onFocus={() => setIsFocused("absent")}
                          onBlur={() => setIsFocused(null)}
                          className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 focus:ring-0 outline-none appearance-none cursor-pointer text-center"
                          required
                        >
                          <option
                            value=""
                            disabled
                            className="dark:bg-slate-900"
                          >
                            No...
                          </option>
                          {Array.from(
                            { length: absentLimit },
                            (_, i) => i + 1,
                          ).map((num) => (
                            <option
                              key={num}
                              value={num.toString()}
                              className="dark:bg-slate-900"
                            >
                              {num}
                            </option>
                          ))}
                        </select>
                        <div className="absolute right-0 top-0 text-slate-400 pointer-events-none">
                          <ChevronDownIcon className="w-4 h-4" />
                        </div>
                      </div>
                    ) : (
                      <input
                        type="text"
                        value={absentNumber}
                        onChange={(e) => setAbsentNumber(e.target.value)}
                        onFocus={() => setIsFocused("absent")}
                        onBlur={() => setIsFocused(null)}
                        className="block w-full bg-transparent border-none p-0 pb-2 text-sm font-bold text-slate-800 dark:text-slate-100 placeholder:text-slate-300 dark:placeholder:text-slate-600 focus:ring-0 outline-none text-center font-mono"
                        placeholder="00 / NIS"
                        required
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4 py-1">
              <div className="h-px bg-slate-100 dark:bg-slate-800 flex-1"></div>
              <div className="text-[10px] font-bold text-slate-300 dark:text-slate-600 uppercase tracking-widest">
                Akses Ujian
              </div>
              <div className="h-px bg-slate-100 dark:bg-slate-800 flex-1"></div>
            </div>

            <div
              className={`relative group transition-all duration-300 ${isFocused === "code" ? "scale-[1.02]" : ""}`}
            >
              <div
                className={`absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl opacity-0 group-hover:opacity-20 transition duration-500 blur ${isFocused === "code" ? "opacity-30" : ""}`}
              ></div>
              <div
                className={`relative bg-white dark:bg-slate-900 rounded-xl p-1 flex items-center shadow-sm border transition-colors ${isFocused === "code" ? "border-indigo-100 dark:border-indigo-500" : "border-slate-100 dark:border-slate-800"}`}
              >
                <button
                  type="button"
                  onClick={() => setIsQrScannerOpen(true)}
                  className="w-10 h-10 flex items-center justify-center rounded-lg bg-slate-50 dark:bg-slate-800 text-indigo-500 dark:text-indigo-400 shrink-0 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors cursor-pointer active:scale-95"
                  title="Pindai QR Code"
                >
                  <QrCodeIcon className="w-5 h-5" />
                </button>
                <div className="h-6 w-px bg-slate-100 dark:bg-slate-800 mx-2"></div>
                <input
                  ref={examCodeInputRef}
                  type="text"
                  value={examCode}
                  onChange={(e) => setExamCode(e.target.value)}
                  onFocus={() => setIsFocused("code")}
                  onBlur={() => setIsFocused(null)}
                  className="w-full bg-transparent py-2 text-center font-code text-lg font-bold tracking-[0.25em] text-slate-800 dark:text-slate-100 placeholder:text-slate-200 dark:placeholder:text-slate-700 outline-none uppercase"
                  placeholder={isCheckingCode ? "CARI..." : "KODE"}
                  autoComplete="off"
                  maxLength={6}
                  required
                />
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-3 p-3 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 text-rose-600 dark:text-rose-400 text-xs font-medium animate-fast-fade">
                <div className="shrink-0 mt-0.5 w-4 h-4 rounded-full bg-rose-100 dark:bg-rose-800 flex items-center justify-center text-rose-500 dark:text-rose-300 font-bold">
                  !
                </div>
                <p>{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading || isCheckingCode}
              className="w-full bg-slate-900 dark:bg-indigo-600 text-white font-bold text-sm h-[48px] rounded-xl hover:bg-black dark:hover:bg-indigo-700 hover:shadow-xl hover:shadow-slate-200 dark:hover:shadow-indigo-900/30 transition-all active:scale-[0.98] mt-4 flex items-center justify-center gap-3 group relative overflow-hidden disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <span className="relative z-10">Memproses...</span>
                  <div className="absolute inset-0 bg-slate-800 dark:bg-indigo-700"></div>
                </>
              ) : (
                <>
                  <span className="relative z-10">Mulai Mengerjakan</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-indigo-600 opacity-0 group-hover:opacity-10 transition-opacity"></div>
                  <CheckCircleIcon className="w-4 h-4 text-emerald-400 dark:text-emerald-200 group-hover:text-emerald-300 transition-colors relative z-10" />
                </>
              )}
            </button>
          </form>
        </div>

        <div className="mt-4 text-center">
          <p className="text-[10px] font-bold text-slate-300 dark:text-slate-600 uppercase tracking-[0.2em]">
            Platform Ujian Cerdas
          </p>
        </div>
      </div>

      {isQrScannerOpen && (
        <QrScannerModal
          onScanSuccess={(text) => {
            let code = text;
            try {
              const url = new URL(text);
              const joinCode = url.searchParams.get("join");
              if (joinCode) code = joinCode;
            } catch {
              /* ignore */
            }
            setExamCode(code);
            setIsQrScannerOpen(false);
          }}
          onClose={() => setIsQrScannerOpen(false)}
        />
      )}

      {pendingStudentData && (
        <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl shadow-2xl w-full max-w-md relative animate-slide-in-up border border-white dark:border-slate-700">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-indigo-50 dark:bg-indigo-900/30 text-indigo-500 dark:text-indigo-400 mb-4">
              <UserIcon className="w-6 h-6" />
            </div>
            <h3 className="font-black text-slate-800 dark:text-white text-xl mb-1 tracking-tight">
              Konfirmasi Data Diri
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
              Pastikan data di bawah ini adalah benar milik Anda sebelum memulai
              ujian.
            </p>

            <div className="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-5 border border-slate-100 dark:border-slate-700/50 space-y-4 mb-6">
              <div>
                <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">
                  Nama Sekolah
                </p>
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  {pendingStudentData.studentData.schoolName || "-"}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">
                  Nama Siswa
                </p>
                <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  {pendingStudentData.studentData.fullName}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">
                    Kelas
                  </p>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {pendingStudentData.studentData.class}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1 font-sans">
                    No. Absen / NIS
                  </p>
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-200 font-mono">
                    {pendingStudentData.studentData.absentNumber}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setPendingStudentData(null);
                  setIsLoading(false);
                }}
                className="flex-1 py-3 text-xs font-bold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors uppercase tracking-wide"
              >
                Bukan, Kembali
              </button>
              <button
                onClick={() => {
                  onLoginSuccess(
                    pendingStudentData.cleanExamCode,
                    pendingStudentData.studentData,
                  );
                  setPendingStudentData(null);
                }}
                className="flex-[1.5] py-3 text-xs font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 dark:shadow-indigo-900/30 transition-all uppercase tracking-wide flex items-center justify-center gap-2"
              >
                <CheckCircleIcon className="w-4 h-4" />
                Ya, Data Sudah Benar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
