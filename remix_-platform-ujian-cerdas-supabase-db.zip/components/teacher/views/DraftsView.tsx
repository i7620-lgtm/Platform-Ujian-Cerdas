import React from "react";
import { createPortal } from "react-dom";
import type { Exam } from "../../../types";
import {
  PencilIcon,
  TrashIcon,
  CalendarDaysIcon,
  ListBulletIcon,
  XMarkIcon,
  EyeIcon,
} from "../../Icons";
import { MetaBadge } from "./SharedComponents";
import { useDraftsView } from "../useDraftsView";

interface PreviewModalProps {
  exam: Exam;
  onClose: () => void;
  onCopyLink: (exam: Exam) => void;
}

const PreviewModal: React.FC<PreviewModalProps> = ({
  exam,
  onClose,
  onCopyLink,
}) => {
  return createPortal(
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-slide-in-up border border-white dark:border-slate-700 max-h-[95vh] flex flex-col">
        <div className="p-3 border-b bg-gray-50 dark:bg-slate-900 border-gray-100 dark:border-slate-700 flex justify-between items-center shrink-0">
          <h3 className="font-bold text-base text-gray-800 dark:text-white">
            Preview Ujian
          </h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-200 dark:hover:bg-slate-700 rounded-full transition-colors"
          >
            <XMarkIcon className="w-5 h-5 text-gray-500 dark:text-slate-400" />
          </button>
        </div>
        <div className="p-5 flex flex-col items-center text-center overflow-y-auto">
          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center mb-3 shadow-inner shrink-0">
            <EyeIcon className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-0.5 leading-tight">
            {exam.config.subject || "Draf Ujian"}
          </h4>
          <p className="text-xs text-gray-500 dark:text-slate-400 mb-4 font-code slashed-zero bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded border border-gray-200 dark:border-slate-600">
            {exam.code}
          </p>
          <div className="bg-white p-2 rounded-xl border border-gray-200 shadow-sm mb-4 shrink-0">
            <img
              src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(`${window.location.origin}/?preview=${exam.code}`)}&margin=10`}
              alt="QR Preview"
              className="w-32 h-32 object-contain"
            />
          </div>
          <p className="text-[10px] text-gray-400 dark:text-slate-500 mb-4 max-w-xs leading-relaxed">
            Pindai QR Code atau gunakan link di bawah untuk mencoba mengerjakan
            soal ini (Mode Preview).
          </p>
          <div className="flex gap-2 w-full shrink-0">
            <button
              onClick={() => onCopyLink(exam)}
              className="flex-1 bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-200 font-bold py-2.5 px-3 rounded-xl hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors text-xs"
            >
              Salin Link
            </button>
            <a
              href={`/?preview=${exam.code}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 bg-blue-600 text-white font-bold py-2.5 px-3 rounded-xl hover:bg-blue-700 transition-colors text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-200 dark:shadow-none"
            >
              Coba Sekarang
            </a>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
};

interface DraftExamCardProps {
  exam: Exam;
  onDelete: () => void;
  onPreview: () => void;
  onContinue: () => void;
}

const DraftExamCard: React.FC<DraftExamCardProps> = ({
  exam,
  onDelete,
  onPreview,
  onContinue,
}) => {
  return (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-gray-100 dark:border-slate-700 shadow-sm hover:shadow-lg transition-all duration-300 relative group flex flex-col h-full">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
        className="absolute top-3 right-3 p-2 bg-white dark:bg-slate-700 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 border border-gray-100 dark:border-slate-600 hover:border-red-100 rounded-full transition-all shadow-sm z-10"
        title="Hapus Draf"
      >
        <TrashIcon className="w-4 h-4" />
      </button>

      <div className="flex-1">
        <div className="flex items-start justify-between mb-2">
          <span className="text-[10px] font-bold bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-slate-300 px-2 py-1 rounded-md uppercase tracking-wider border border-gray-200 dark:border-slate-600">
            Draft
          </span>
        </div>
        <h3 className="font-bold text-lg text-gray-800 dark:text-white mb-1">
          {exam.config.subject || "Tanpa Judul"}
        </h3>
        <p className="text-sm text-gray-400 dark:text-slate-500 font-code slashed-zero font-medium mb-3">
          {exam.code}
        </p>
        <div className="flex flex-wrap gap-2 mb-4">
          <MetaBadge
            text={exam.config.classLevel}
            colorClass="bg-blue-50 text-blue-700 border-blue-100"
          />
          <MetaBadge
            text={exam.config.examType}
            colorClass="bg-purple-50 text-purple-700 border-purple-100"
          />
          {exam.config.targetClasses &&
            exam.config.targetClasses.length > 0 && (
              <MetaBadge
                text={exam.config.targetClasses.join(", ")}
                colorClass="bg-orange-50 text-orange-700 border-orange-100"
              />
            )}
        </div>
        <div className="h-px bg-gray-50 dark:bg-slate-700 w-full mb-4"></div>
        <div className="text-xs text-gray-500 dark:text-slate-400 space-y-2 mb-6">
          <div className="flex items-center gap-2">
            <CalendarDaysIcon className="w-4 h-4 text-gray-400 dark:text-slate-500" />
            <span>
              {new Date(exam.config.date).toLocaleDateString("id-ID", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <ListBulletIcon className="w-4 h-4 text-gray-400 dark:text-slate-500" />
            <span>
              {exam.questions.filter((q) => q.questionType !== "INFO").length}{" "}
              Soal Tersimpan
            </span>
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          onClick={onPreview}
          className="flex-1 py-2.5 px-3 bg-white dark:bg-slate-700 border border-gray-200 dark:border-slate-600 text-gray-600 dark:text-slate-300 font-bold rounded-xl hover:bg-gray-50 dark:hover:bg-slate-600 hover:text-primary dark:hover:text-white transition-colors flex items-center justify-center gap-2 shadow-sm"
          title="Preview Soal"
        >
          <EyeIcon className="w-4 h-4" /> Preview
        </button>
        <button
          onClick={onContinue}
          className="flex-[2] py-2.5 px-4 bg-white dark:bg-slate-700 border border-gray-200 dark:border-slate-600 text-gray-700 dark:text-white font-bold rounded-xl hover:bg-gray-50 dark:hover:bg-slate-600 hover:border-gray-300 transition-colors flex items-center justify-center gap-2 shadow-sm"
        >
          <PencilIcon className="w-4 h-4" /> Edit
        </button>
      </div>
    </div>
  );
};

interface DraftsViewProps {
  exams: Exam[];
  onDeleteDraft: (exam: Exam) => void;
  onContinueDraft: (exam: Exam) => void;
}

export const DraftsView: React.FC<DraftsViewProps> = ({
  exams,
  onDeleteDraft,
  onContinueDraft,
}) => {
  const { previewExam, setPreviewExam, handleCopyPreviewLink } =
    useDraftsView();

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-2">
        <div className="p-2 bg-gray-100 dark:bg-slate-800 rounded-lg">
          <PencilIcon className="w-6 h-6 text-gray-600 dark:text-slate-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-neutral dark:text-white">
            Draf Soal
          </h2>
          <p className="text-sm text-gray-500 dark:text-slate-400">
            Lanjutkan pembuatan soal yang belum selesai.
          </p>
        </div>
      </div>

      {exams.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exams.map((exam) => (
            <DraftExamCard
              key={exam.code}
              exam={exam}
              onDelete={() => onDeleteDraft(exam)}
              onPreview={() => setPreviewExam(exam)}
              onContinue={() => onContinueDraft(exam)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white dark:bg-slate-800 rounded-2xl border border-dashed border-gray-200 dark:border-slate-700">
          <div className="bg-gray-50 dark:bg-slate-700 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <PencilIcon className="h-8 w-8 text-gray-300 dark:text-slate-500" />
          </div>
          <h3 className="text-base font-bold text-gray-900 dark:text-white">
            Belum Ada Draf
          </h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">
            Anda belum menyimpan draf soal apapun.
          </p>
        </div>
      )}

      {previewExam && (
        <PreviewModal
          exam={previewExam}
          onClose={() => setPreviewExam(null)}
          onCopyLink={handleCopyPreviewLink}
        />
      )}
    </div>
  );
};
