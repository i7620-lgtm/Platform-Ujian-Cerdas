import React from "react";
import type { Exam, TeacherProfile } from "../../../types";
import {
  CalendarDaysIcon,
  ClockIcon,
  PencilIcon,
  EnvelopeIcon,
  UserIcon,
  DocumentDuplicateIcon,
  EyeIcon,
  TrashIcon,
} from "../../Icons";
import { MetaBadge } from "./SharedComponents";
import { InvitationModal } from "../InvitationModal";
import { CollaboratorModal } from "../CollaboratorModal";
import { useUpcomingExamsView } from "../useUpcomingExamsView";

interface UpcomingExamsViewProps {
  exams: Exam[];
  teacherProfile: TeacherProfile;
  onDeleteExam: (exam: Exam) => void;
  onRefresh?: () => void;
  onEditExam: (exam: Exam) => void;
  onDuplicateExam: (exam: Exam) => void;
}

export const UpcomingExamsView: React.FC<UpcomingExamsViewProps> = ({
  exams,
  teacherProfile,
  onDeleteExam,
  onRefresh,
  onEditExam,
  onDuplicateExam,
}) => {
  const {
    selectedInviteExam,
    selectedCollaboratorExam,
    setSelectedInviteExam,
    setSelectedCollaboratorExam,
    teacherName,
    schoolName,
  } = useUpcomingExamsView({ teacherProfile });

  return (
    <div
      id="upcoming-exams-view-container"
      className="space-y-6 animate-fade-in"
    >
      <div className="flex items-center gap-2">
        <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
          <CalendarDaysIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-neutral dark:text-white">
            Ujian Akan Datang
          </h2>
          <p className="text-sm text-gray-500 dark:text-slate-400">
            Daftar semua ujian yang telah dijadwalkan.
          </p>
        </div>
      </div>

      {exams.length > 0 ? (
        <div id="upcoming-exams-list" className="space-y-4">
          {exams.map((exam) => (
            <div
              key={exam.code}
              id={`upcoming-exam-card-${exam.code}`}
              className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-gray-100 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:shadow-md hover:border-blue-200 dark:hover:border-blue-800 group"
            >
              <div className="flex items-start gap-5">
                {(() => {
                  const startDate =
                    exam.config.startDate || exam.config.date || "";
                  const d = startDate.includes("T")
                    ? new Date(startDate)
                    : new Date(
                        `${startDate}T${exam.config.startTime || "00:00"}`,
                      );
                  return (
                    <div className="bg-blue-50 dark:bg-blue-900/20 w-14 h-14 rounded-2xl flex flex-col items-center justify-center text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800 shrink-0">
                      <span className="text-[10px] font-bold uppercase">
                        {d.toLocaleDateString("id-ID", { month: "short" })}
                      </span>
                      <span className="text-xl font-black leading-none">
                        {d.getDate()}
                      </span>
                    </div>
                  );
                })()}
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-lg text-neutral dark:text-white">
                      {exam.config.subject || "Tanpa Judul"}
                    </h3>
                    <span className="text-xs font-code slashed-zero text-gray-400 dark:text-slate-500 bg-gray-50 dark:bg-slate-700 px-1.5 py-0.5 rounded">
                      {exam.code}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <MetaBadge
                      text={exam.config.classLevel}
                      colorClass="bg-gray-100 text-gray-600"
                    />
                    <MetaBadge
                      text={exam.config.examType}
                      colorClass="bg-gray-100 text-gray-600"
                    />
                    {exam.config.targetClasses &&
                      exam.config.targetClasses.length > 0 && (
                        <MetaBadge
                          text={exam.config.targetClasses.join(", ")}
                          colorClass="bg-orange-50 text-orange-700 border-orange-100"
                        />
                      )}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-slate-400 flex items-center gap-3 font-medium">
                    <span className="flex items-center gap-1.5">
                      <ClockIcon className="w-3.5 h-3.5" />{" "}
                      {(() => {
                        const startDate =
                          exam.config.startDate || exam.config.date || "";
                        const d = startDate.includes("T")
                          ? new Date(startDate)
                          : new Date(
                              `${startDate}T${exam.config.startTime || "00:00"}`,
                            );
                        return (
                          d.toLocaleTimeString("id-ID", {
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: false,
                          }) +
                          " " +
                          (d
                            .toLocaleTimeString("id-ID", {
                              timeZoneName: "short",
                            })
                            .split(" ")
                            .pop() || "")
                        );
                      })()}
                    </span>
                    <span className="text-gray-300 dark:text-slate-600">•</span>
                    <span>
                      {exam.config.examMode === "PR"
                        ? "Tanpa Batas"
                        : exam.config.timeLimit > 0
                          ? `${exam.config.timeLimit} Menit`
                          : "Tanpa Batas"}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 self-end md:self-center w-full md:w-auto flex-wrap">
                <button
                  id={`btn-preview-${exam.code}`}
                  onClick={() =>
                    window.open(`/?preview=${exam.code}`, "_blank")
                  }
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 px-5 py-2.5 text-sm rounded-xl hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-all font-bold shadow-sm border border-amber-100 dark:border-amber-800"
                  title="Preview Soal"
                >
                  <EyeIcon className="w-4 h-4" />
                  <span className="hidden lg:inline">Preview</span>
                </button>
                <button
                  id={`btn-duplicate-${exam.code}`}
                  onClick={() => onDuplicateExam(exam)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gray-50 dark:bg-slate-700/50 text-gray-600 dark:text-slate-400 px-5 py-2.5 text-sm rounded-xl hover:bg-gray-100 dark:hover:bg-slate-700 hover:text-primary dark:hover:text-white transition-all font-bold shadow-sm border border-gray-200 dark:border-slate-600"
                  title="Duplikasi Soal"
                >
                  <DocumentDuplicateIcon className="w-4 h-4" />
                  <span className="hidden lg:inline">Duplikasi</span>
                </button>
                <button
                  id={`btn-collab-${exam.code}`}
                  onClick={() => setSelectedCollaboratorExam(exam)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 px-5 py-2.5 text-sm rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-all font-bold shadow-sm border border-emerald-100 dark:border-emerald-800"
                  title="Kelola Kolaborator"
                >
                  <UserIcon className="w-4 h-4" />
                  <span className="hidden lg:inline">Kolaborator</span>
                </button>
                <button
                  id={`btn-invite-${exam.code}`}
                  onClick={() => setSelectedInviteExam(exam)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-5 py-2.5 text-sm rounded-xl hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all font-bold shadow-sm border border-indigo-100 dark:border-indigo-800"
                >
                  <EnvelopeIcon className="w-4 h-4" />
                  Undangan
                </button>
                <button
                  id={`btn-edit-${exam.code}`}
                  onClick={() => onEditExam(exam)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-white dark:bg-slate-700 border-2 border-gray-100 dark:border-slate-600 text-gray-600 dark:text-slate-300 px-5 py-2.5 text-sm rounded-xl hover:border-primary dark:hover:border-primary hover:text-primary dark:hover:text-white transition-all font-bold shadow-sm"
                >
                  <PencilIcon className="w-4 h-4" />
                  Edit
                </button>
                <button
                  id={`btn-delete-${exam.code}`}
                  onClick={() => onDeleteExam(exam)}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-5 py-2.5 text-sm rounded-xl hover:bg-red-100 dark:hover:bg-red-900/50 transition-all font-bold shadow-sm border border-red-100 dark:border-red-800"
                  title="Hapus Ujian"
                >
                  <TrashIcon className="w-4 h-4" />
                  <span className="hidden lg:inline">Hapus</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div
          id="no-upcoming-exams"
          className="text-center py-20 bg-white dark:bg-slate-800 rounded-2xl border border-gray-100 dark:border-slate-700"
        >
          <div className="bg-gray-50 dark:bg-slate-700 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <CalendarDaysIcon className="h-8 w-8 text-gray-300 dark:text-slate-500" />
          </div>
          <h3 className="text-base font-bold text-gray-900 dark:text-white">
            Tidak Ada Ujian Terjadwal
          </h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-slate-400">
            Buat ujian baru untuk memulai.
          </p>
        </div>
      )}

      {/* Modal Undangan Spesifik */}
      <InvitationModal
        isOpen={!!selectedInviteExam}
        onClose={() => setSelectedInviteExam(null)}
        exam={selectedInviteExam}
        teacherName={teacherName}
        schoolName={schoolName}
      />

      {/* Modal Kolaborator */}
      {selectedCollaboratorExam && (
        <CollaboratorModal
          exam={
            exams.find((e) => e.code === selectedCollaboratorExam.code) ||
            selectedCollaboratorExam
          }
          onClose={() => setSelectedCollaboratorExam(null)}
          onUpdate={() => {
            if (onRefresh) onRefresh();
          }}
        />
      )}
    </div>
  );
};
