import React, { useState, useEffect, useRef, useCallback } from "react";
import type { Exam, Student, Result, Question, ResultStatus } from "../types";
import {
  ClockIcon,
  CheckCircleIcon,
  PencilIcon,
  ChevronDownIcon,
  CheckIcon,
  ChevronUpIcon,
  LockClosedIcon,
  SunIcon,
  MoonIcon,
  ShieldCheckIcon,
  MapPinIcon,
  ArrowsRightLeftIcon,
} from "./Icons";
import { storageService } from "../services/storage";
import { supabase } from "../lib/supabase";
import type { RealtimeChannel } from "@supabase/supabase-js";
import {
  parseList,
  sanitizeHtml,
  calculateExamScore,
} from "./teacher/examUtils";
import { AudioPlayer } from "./AudioPlayer";
import { ChartRenderer } from "./ChartRenderer";
import type { ChartData } from "../types";
import { useExamAntiCheat } from "../hooks/useExamAntiCheat";
import { MultipleChoiceView } from "./student/question-types/MultipleChoiceView";
import { TrueFalseView } from "./student/question-types/TrueFalseView";
import { MatchingView } from "./student/question-types/MatchingView";

const renderQuestionTextWithChart = (
  html: string,
  chartData: ChartData | undefined,
  optimizeHtml: (h: string) => string,
) => {
  const optimized = optimizeHtml(html);
  if (!chartData) {
    return <div dangerouslySetInnerHTML={{ __html: optimized }}></div>;
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(optimized, "text/html");
  const chartNode = doc.querySelector('[data-chart="true"]');

  if (!chartNode) {
    return (
      <>
        <div dangerouslySetInnerHTML={{ __html: optimized }}></div>
        <div className="mb-8 w-full max-w-3xl mx-auto">
          <ChartRenderer data={chartData} />
        </div>
      </>
    );
  }

  const marker = "___CHART_MARKER___";
  chartNode.insertAdjacentText("beforebegin", marker);
  chartNode.remove();

  const newHtml = doc.body.innerHTML;
  const parts = newHtml.split(marker);

  return (
    <>
      {parts.map((part, index) => (
        <React.Fragment key={index}>
          <div dangerouslySetInnerHTML={{ __html: part }}></div>
          {index < parts.length - 1 && (
            <div className="my-6 w-full max-w-3xl mx-auto">
              <ChartRenderer data={chartData} />
            </div>
          )}
        </React.Fragment>
      ))}
    </>
  );
};

interface StudentExamPageProps {
  exam: Exam;
  student: Student;
  initialData?: Result | null;
  onSubmit: (
    answers: Record<string, string>,
    timeLeft: number,
    status?: ResultStatus,
    logs?: string[],
    location?: string,
    grading?: Record<string, unknown>,
  ) => void;
  onUpdate?: (answers: Record<string, string>, timeLeft: number) => void;
  isDarkMode?: boolean;
  toggleTheme?: () => void;
}

export const StudentExamPage: React.FC<StudentExamPageProps> = ({
  exam,
  student,
  initialData,
  onSubmit,
  isDarkMode,
  toggleTheme,
}) => {
  const STORAGE_KEY = `exam_local_${exam.code}_${student.studentId}`;
  const CACHED_EXAM_KEY = `exam_def_${exam.code}`;

  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userLocation, setUserLocation] = useState<string>("");

  const [isNavOpen, setIsNavOpen] = useState(false);
  const [hasAttemptedSubmit, setHasAttemptedSubmit] = useState(false);
  const [showConfigIntro, setShowConfigIntro] = useState(true);

  const [activeExam, setActiveExam] = useState<Exam>(exam);

  const answersRef = useRef<Record<string, string>>({});
  const logRef = useRef<string[]>(initialData?.activityLog || []);
  const isSubmittingRef = useRef(false);
  const timeLeftRef = useRef(0);
  const lastBroadcastTimeRef = useRef<number>(0);
  const examRoomChannelRef = useRef<RealtimeChannel | null>(null);

  const [matchingOptionsMap] = useState<Record<string, string[]>>(() => {
    const map: Record<string, string[]> = {};
    activeExam?.questions.forEach((q) => {
      if (q.questionType === "MATCHING" && q.matchingPairs) {
        const opts = q.matchingPairs.map((p) => p.right);
        for (let i = opts.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [opts[i], opts[j]] = [opts[j], opts[i]];
        }
        map[q.id] = opts;
      }
    });
    return map;
  });

  // Monitoring Status
  const isMonitoring =
    activeExam.config.detectBehavior && activeExam.config.examMode !== "PR";
  const monitoringLabel = activeExam.config.continueWithPermission
    ? "Diawasi & Terkunci"
    : "Diawasi Sistem";

  const isAnswered = (q: Question, currentAnswers: Record<string, string>) => {
    const ans = currentAnswers[q.id];
    if (!ans) return false;
    if (q.questionType === "COMPLEX_MULTIPLE_CHOICE") {
      try {
        const parsed = JSON.parse(ans);
        return Array.isArray(parsed) && parsed.length > 0;
      } catch {
        return false;
      }
    }
    if (q.questionType === "TRUE_FALSE") {
      try {
        const parsed = JSON.parse(ans);
        const rowCount = q.trueFalseRows?.length || 0;
        return Object.keys(parsed).length >= rowCount && rowCount > 0;
      } catch {
        return false;
      }
    }
    if (q.questionType === "MATCHING") {
      try {
        const parsed = JSON.parse(ans);
        const pairCount = q.matchingPairs?.length || 0;
        return Object.keys(parsed).length >= pairCount && pairCount > 0;
      } catch {
        return false;
      }
    }
    return ans.trim().length > 0;
  };

  const handleSubmit = useCallback(
    async (isAuto = false, status: ResultStatus = "completed") => {
      if (isSubmittingRef.current) return;

      if (!isAuto) {
        setHasAttemptedSubmit(true);
        const unansweredCount = activeExam.questions.filter(
          (q) =>
            q.questionType !== "INFO" && !isAnswered(q, answersRef.current),
        ).length;

        let confirmMsg = "Yakin ingin mengumpulkan jawaban sekarang?";
        if (unansweredCount > 0) {
          confirmMsg = `Masih ada ${unansweredCount} soal yang belum dijawab atau belum lengkap. Yakin ingin mengumpulkan sekarang?`;
        }

        if (!window.confirm(confirmMsg)) return;
      }

      setIsSubmitting(true);
      isSubmittingRef.current = true;

      try {
        if (status === "completed" || status === "force_closed") {
          const startTimeStr = answersRef.current["_startTime"];
          if (startTimeStr) {
            const startTime = parseInt(startTimeStr);
            const durationInSeconds = Math.floor(
              (Date.now() - startTime) / 1000,
            );
            answersRef.current["_duration"] = durationInSeconds.toString();
          }
        }

        const grading = calculateExamScore(activeExam, answersRef.current);
        await onSubmit(
          answersRef.current,
          timeLeftRef.current,
          status,
          logRef.current,
          userLocation,
          grading,
        );

        if (examRoomChannelRef.current) {
          examRoomChannelRef.current
            .send({
              type: "broadcast",
              event: "student_submitted",
              payload: { studentId: student.studentId, status },
            })
            .catch(() => {});
        }

        await storageService.clearLocalProgress(STORAGE_KEY);
      } catch (error) {
        console.error("Submit error:", error);
        alert("Gagal mengirim jawaban. Silakan coba lagi.");
        setIsSubmitting(false);
        isSubmittingRef.current = false;
      }
    },
    [activeExam, onSubmit, userLocation, STORAGE_KEY, student.studentId],
  );

  const { timeLeft } = useExamAntiCheat({
    student,
    exam: activeExam,
    initialData,
    storageKey: STORAGE_KEY,
    answersRef,
    logRef,
    timeLeftRef,
    onForceSubmit: handleSubmit,
    isSubmitting,
  });

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;
    let resultChannel: ReturnType<typeof supabase.channel> | null = null;
    // HARD BLOCK: Ensure Realtime is ONLY enabled if disableRealtime is explicitly false.
    // This prevents students in "Normal Mode" from consuming Realtime Concurrent Peak Connections.
    const isRealtimeEnabled = exam.config.disableRealtime === false;

    if (isRealtimeEnabled) {
      const channelName = `exam-room-${exam.code}`;
      channel = supabase
        .channel(channelName, {
          config: { presence: { key: student.studentId } },
        })
        .on("broadcast", { event: "force_submit_exam" }, (payload) => {
          // If studentId is provided in payload, only submit if it matches current student
          if (
            payload.payload?.studentId &&
            payload.payload.studentId !== student.studentId
          )
            return;

          if (student.class !== "PREVIEW" && !isSubmittingRef.current) {
            alert(
              "Ujian telah dihentikan oleh Guru. Jawaban Anda akan dikumpulkan otomatis.",
            );
            handleSubmit(true, "completed");
          }
        })
        .subscribe(async (status) => {
          if (status === "SUBSCRIBED") {
            await channel
              ?.track({
                studentId: student.studentId,
                onlineAt: new Date().toISOString(),
              })
              .catch(() => {});
          }
        });

      examRoomChannelRef.current = channel;

      if (student.resultId) {
        resultChannel = supabase
          .channel(`student-result-${student.resultId}`)
          .on(
            "postgres_changes",
            {
              event: "UPDATE",
              schema: "public",
              table: "results",
              filter: `id=eq.${student.resultId}`,
            },
            (payload) => {
              const newStatus = payload.new.status;
              if (
                (newStatus === "completed" || newStatus === "force_closed") &&
                !isSubmittingRef.current &&
                student.class !== "PREVIEW"
              ) {
                alert(
                  "Ujian telah dihentikan oleh Guru. Jawaban Anda akan dikumpulkan otomatis.",
                );
                handleSubmit(true, newStatus);
              }
            },
          )
          .subscribe();
      }
    }
    return () => {
      if (channel) supabase.removeChannel(channel);
      if (resultChannel) supabase.removeChannel(resultChannel);
    };
  }, [
    exam.code,
    exam.config.disableRealtime,
    student.studentId,
    student.class,
    student.resultId,
    handleSubmit,
  ]);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;
    // HARD BLOCK: Ensure Realtime is ONLY enabled if disableRealtime is explicitly false.
    const isRealtimeEnabled = exam.config.disableRealtime === false;

    if (isRealtimeEnabled) {
      channel = supabase
        .channel(`exam-config-${exam.code}`)
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "exams",
            filter: `code=eq.${exam.code}`,
          },
          (payload) => {
            const newConfig = payload.new.config;
            if (newConfig) {
              setActiveExam((prev) => {
                return { ...prev, config: newConfig };
              });
            }
          },
        )
        .subscribe();
    }

    let pollTimeout: NodeJS.Timeout;
    let isPolling = true;

    const pollData = async () => {
      if (!isPolling) return;
      if (typeof navigator !== "undefined" && navigator.onLine !== false) {
        try {
          // Select extreme for exams
          const { data } = await supabase
            .from("exams")
            .select("status, config, unlock_token")
            .eq("code", exam.code)
            .single();
          if (data) {
            if (data.status === "closed" && !isSubmittingRef.current) {
              alert("Ujian telah ditutup oleh Guru.");
              handleSubmit(true, "force_closed");
              return;
            }
            if (data.config) {
              setActiveExam((prev) => {
                if (prev.config.timeLimit !== data.config.timeLimit) {
                  return { ...prev, config: data.config };
                }
                return { ...prev, config: data.config };
              });
            }
          }

          // Select extreme for results
          if (student.resultId && student.class !== "PREVIEW") {
            const { data: resultData } = await supabase
              .from("results")
              .select("status, student_id")
              .eq("id", student.resultId)
              .single();
            if (
              resultData &&
              (resultData.status === "completed" ||
                resultData.status === "force_closed") &&
              !isSubmittingRef.current
            ) {
              alert(
                "Ujian telah dihentikan oleh Guru. Jawaban Anda akan dikumpulkan otomatis.",
              );
              handleSubmit(true, resultData.status);
              return;
            }
          }
        } catch {
          /* ignore */
        }
      }

      // Calculate next interval based on time left
      let nextInterval = 60000; // 1 minute default
      if (timeLeftRef.current !== undefined && timeLeftRef.current <= 300) {
        // 5 minutes = 300 seconds
        nextInterval = 15000; // 15 seconds
      }

      if (isPolling) {
        pollTimeout = setTimeout(pollData, nextInterval);
      }
    };

    // Start polling
    pollTimeout = setTimeout(pollData, 60000);

    return () => {
      isPolling = false;
      if (channel) supabase.removeChannel(channel);
      clearTimeout(pollTimeout);
    };
  }, [
    exam.code,
    exam.config.disableRealtime,
    student.resultId,
    student.class,
    handleSubmit,
  ]);

  const isLoadedRef = useRef(false);
  const prevStorageKeyRef = useRef(STORAGE_KEY);
  const loadPromiseRef = useRef<Promise<void> | null>(null);

  useEffect(() => {
    if (prevStorageKeyRef.current !== STORAGE_KEY) {
      const oldKey = prevStorageKeyRef.current;
      const newKey = STORAGE_KEY;
      prevStorageKeyRef.current = STORAGE_KEY;

      const copyData = async () => {
        if (loadPromiseRef.current) {
          await loadPromiseRef.current;
        }
        storageService.saveLocalProgress(newKey, {
          answers: answersRef.current,
          logs: logRef.current,
          lastUpdated: Date.now(),
        });
        storageService.clearLocalProgress(oldKey);
      };
      copyData();
    }
  }, [STORAGE_KEY]);

  useEffect(() => {
    const loadState = async () => {
      if (isLoadedRef.current) return;
      isLoadedRef.current = true;

      loadPromiseRef.current = (async () => {
        try {
          localStorage.setItem(CACHED_EXAM_KEY, JSON.stringify(exam));
        } catch {
          /* ignore */
        }
        const localData = (await storageService.getLocalProgress(
          STORAGE_KEY,
        )) as { answers?: Record<string, string>; logs?: string[] } | null;
        if (localData) {
          const loadedAnswers = localData.answers || {};
          // Fix sorting for old data
          Object.keys(loadedAnswers).forEach((qId) => {
            const q = activeExam.questions.find((q) => q.id === qId);
            if (q) {
              if (q.questionType === "COMPLEX_MULTIPLE_CHOICE") {
                try {
                  const parsed = JSON.parse(loadedAnswers[qId]);
                  if (Array.isArray(parsed)) {
                    parsed.sort(
                      (a, b) =>
                        (q.options || []).indexOf(a) -
                        (q.options || []).indexOf(b),
                    );
                    loadedAnswers[qId] = JSON.stringify(parsed);
                  }
                } catch {
                  /* ignore */
                }
              } else if (
                q.questionType === "TRUE_FALSE" ||
                q.questionType === "MATCHING"
              ) {
                try {
                  const parsed = JSON.parse(loadedAnswers[qId]);
                  if (typeof parsed === "object" && !Array.isArray(parsed)) {
                    const sortedObj: Record<number, string | boolean | number> =
                      {};
                    Object.keys(parsed)
                      .map(Number)
                      .sort((a, b) => a - b)
                      .forEach(
                        (k) =>
                          (sortedObj[k] = (
                            parsed as Record<number, string | boolean | number>
                          )[k]),
                      );
                    loadedAnswers[qId] = JSON.stringify(sortedObj);
                  }
                } catch {
                  /* ignore */
                }
              }
            }
          });
          if (!loadedAnswers["_startTime"]) {
            loadedAnswers["_startTime"] = Date.now().toString();
          }
          setAnswers(loadedAnswers);
          answersRef.current = loadedAnswers;
          if (localData.logs) logRef.current = localData.logs;
          return;
        }
        if (initialData?.answers) {
          const loadedAnswers = { ...initialData.answers };
          // Fix sorting for old data
          Object.keys(loadedAnswers).forEach((qId) => {
            const q = activeExam.questions.find((q) => q.id === qId);
            if (q) {
              if (q.questionType === "COMPLEX_MULTIPLE_CHOICE") {
                try {
                  const parsed = JSON.parse(loadedAnswers[qId]);
                  if (Array.isArray(parsed)) {
                    parsed.sort(
                      (a, b) =>
                        (q.options || []).indexOf(a) -
                        (q.options || []).indexOf(b),
                    );
                    loadedAnswers[qId] = JSON.stringify(parsed);
                  }
                } catch {
                  /* ignore */
                }
              } else if (
                q.questionType === "TRUE_FALSE" ||
                q.questionType === "MATCHING"
              ) {
                try {
                  const parsed = JSON.parse(loadedAnswers[qId]);
                  if (typeof parsed === "object" && !Array.isArray(parsed)) {
                    const sortedObj: Record<number, string | boolean | number> =
                      {};
                    Object.keys(parsed)
                      .map(Number)
                      .sort((a, b) => a - b)
                      .forEach(
                        (k) =>
                          (sortedObj[k] = (
                            parsed as Record<number, string | boolean | number>
                          )[k]),
                      );
                    loadedAnswers[qId] = JSON.stringify(sortedObj);
                  }
                } catch {
                  /* ignore */
                }
              }
            }
          });
          if (!loadedAnswers["_startTime"]) {
            loadedAnswers["_startTime"] = Date.now().toString();
          }
          setAnswers(loadedAnswers);
          answersRef.current = loadedAnswers;
        } else {
          const loadedAnswers = { _startTime: Date.now().toString() };
          setAnswers(loadedAnswers);
          answersRef.current = loadedAnswers;
        }
      })();
      await loadPromiseRef.current;
    };
    loadState();
  }, [STORAGE_KEY, CACHED_EXAM_KEY, initialData, exam, activeExam.questions]);

  useEffect(() => {
    isSubmittingRef.current = isSubmitting;
  }, [isSubmitting]);

  useEffect(() => {
    if (
      activeExam.config.trackLocation &&
      activeExam.config.examMode !== "PR" &&
      student.class !== "PREVIEW" &&
      "geolocation" in navigator
    ) {
      navigator.geolocation.getCurrentPosition((pos) =>
        setUserLocation(`${pos.coords.latitude}, ${pos.coords.longitude}`),
      );
    }
  }, [
    activeExam.config.trackLocation,
    activeExam.config.examMode,
    student.class,
  ]);

  const broadcastProgress = useCallback(() => {
    // HARD BLOCK: If realtime is disabled, we don't even attempt to call the service.
    if (activeExam.config.disableRealtime) return;

    const totalQ = activeExam.questions.filter(
      (q) => q.questionType !== "INFO",
    ).length;
    const answeredQ = activeExam.questions.filter(
      (q) => q.questionType !== "INFO" && isAnswered(q, answersRef.current),
    ).length;
    storageService
      .sendProgressUpdate(
        activeExam.code,
        student.studentId,
        answeredQ,
        totalQ,
        examRoomChannelRef.current,
      )
      .catch(() => {});
  }, [activeExam, student.studentId]);

  const handleAnswerChange = useCallback(
    (qId: string, val: string) => {
      setAnswers((prev) => {
        const next = { ...prev, [qId]: val };
        answersRef.current = next;
        if (student.class !== "PREVIEW") {
          storageService.saveLocalProgress(STORAGE_KEY, {
            answers: next,
            logs: logRef.current,
            lastUpdated: Date.now(),
          });
        }
        return next;
      });
      if (student.class !== "PREVIEW" && !activeExam.config.disableRealtime) {
        const now = Date.now();
        if (now - lastBroadcastTimeRef.current > 2000) {
          broadcastProgress();
          lastBroadcastTimeRef.current = now;
        }
      }
    },
    [
      STORAGE_KEY,
      activeExam.config.disableRealtime,
      broadcastProgress,
      student.class,
    ],
  );

  const scrollToQuestion = (id: string) => {
    setIsNavOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  const formatTime = (s: number) => {
    if (s === Infinity) return "Tanpa Batas Waktu";
    const h = Math.floor(s / 3600),
      m = Math.floor((s % 3600) / 60),
      sec = s % 60;
    return h > 0
      ? `${h}:${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`
      : `${m}:${sec.toString().padStart(2, "0")}`;
  };

  const totalQuestions = activeExam.questions.filter(
    (q) => q.questionType !== "INFO",
  ).length;
  const answeredCount = activeExam.questions.filter(
    (q) => q.questionType !== "INFO" && isAnswered(q, answers),
  ).length;
  const progress =
    totalQuestions > 0 ? (answeredCount / totalQuestions) * 100 : 0;
  const optimizeHtml = (html: string) =>
    sanitizeHtml(html).replace(
      /<img /g,
      '<img loading="lazy" class="rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 max-w-full max-h-[50vh] object-contain h-auto" ',
    );

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-slate-950 font-sans selection:bg-indigo-100 selection:text-indigo-900 pb-40 transition-colors duration-300">
      {/* Modal Informasi Aturan Ujian */}
      {showConfigIntro && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fade-in">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden border border-white dark:border-slate-800 animate-gentle-slide">
            <div className="p-8 sm:p-10">
              <div className="flex justify-center mb-8">
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-3xl text-indigo-600 dark:text-indigo-400">
                  <ShieldCheckIcon className="w-10 h-10" />
                </div>
              </div>

              <h2 className="text-2xl font-black text-slate-800 dark:text-white text-center mb-2 tracking-tight">
                Aturan Ujian
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-8 font-medium">
                Mohon perhatikan konfigurasi ujian berikut:
              </p>

              <div className="space-y-4 mb-10">
                <div className="flex items-center gap-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                  <ClockIcon className="w-5 h-5 text-indigo-500 shrink-0" />
                  <div>
                    <p className="text-xs font-black uppercase text-slate-400 dark:text-slate-500 tracking-widest">
                      Batas Waktu
                    </p>
                    <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
                      {activeExam.config.examMode === "PR"
                        ? "Tanpa Batas"
                        : activeExam.config.timeLimit > 0
                          ? `${activeExam.config.timeLimit} Menit`
                          : "Tanpa Batas"}
                    </p>
                  </div>
                </div>

                {activeExam.config.kkm && (
                  <div className="flex items-center gap-4 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                    <CheckCircleIcon className="w-5 h-5 text-emerald-500 shrink-0" />
                    <div>
                      <p className="text-xs font-black uppercase text-emerald-400 dark:text-emerald-500 tracking-widest">
                        Target Nilai
                      </p>
                      <p className="text-sm font-bold text-emerald-700 dark:text-emerald-300">
                        KKM Minimal {activeExam.config.kkm}
                      </p>
                    </div>
                  </div>
                )}

                {activeExam.config.detectBehavior &&
                  activeExam.config.examMode !== "PR" && (
                    <div className="flex items-center gap-4 p-4 bg-rose-50 dark:bg-rose-900/20 rounded-2xl border border-rose-100 dark:border-rose-900/30">
                      <LockClosedIcon className="w-5 h-5 text-rose-500 shrink-0" />
                      <div>
                        <p className="text-xs font-black uppercase text-rose-400 dark:text-rose-500 tracking-widest">
                          Pengawasan Aktif
                        </p>
                        <p className="text-sm font-bold text-rose-700 dark:text-rose-300">
                          {activeExam.config.continueWithPermission
                            ? "Akses Terkunci Otomatis Jika Curang"
                            : "Aktivitas Tercatat Sistem"}
                        </p>
                      </div>
                    </div>
                  )}

                {(activeExam.config.shuffleQuestions ||
                  activeExam.config.shuffleAnswers) && (
                  <div className="flex items-center gap-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-900/30">
                    <ArrowsRightLeftIcon className="w-5 h-5 text-blue-500 shrink-0" />
                    <div>
                      <p className="text-xs font-black uppercase text-blue-400 dark:text-blue-500 tracking-widest">
                        Mode Acak
                      </p>
                      <p className="text-sm font-bold text-blue-700 dark:text-blue-300">
                        Soal & Jawaban Diacak
                      </p>
                    </div>
                  </div>
                )}

                {activeExam.config.trackLocation &&
                  activeExam.config.examMode !== "PR" && (
                    <div className="flex items-center gap-4 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                      <MapPinIcon className="w-5 h-5 text-emerald-500 shrink-0" />
                      <div>
                        <p className="text-xs font-black uppercase text-emerald-400 dark:text-emerald-500 tracking-widest">
                          Pelacakan Lokasi
                        </p>
                        <p className="text-sm font-bold text-emerald-700 dark:text-emerald-300">
                          Koordinat GPS Dicatat
                        </p>
                      </div>
                    </div>
                  )}
              </div>

              <button
                onClick={() => setShowConfigIntro(false)}
                className="w-full py-4 bg-slate-900 dark:bg-indigo-600 text-white font-bold rounded-2xl shadow-xl hover:shadow-indigo-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2 group"
              >
                <span>Mulai Mengerjakan</span>
                <CheckCircleIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      )}

      <header
        className={`fixed top-0 inset-x-0 z-[60] border-b shadow-sm transition-all duration-300 h-16 flex items-center ${isNavOpen ? "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800" : "bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-slate-200/60 dark:border-slate-800/60"}`}
      >
        <div
          className="absolute top-0 left-0 h-[2px] bg-indigo-600 dark:bg-indigo-500 transition-all duration-700 ease-out z-10"
          style={{ width: `${progress}%` }}
        ></div>
        <div className="w-full max-w-full mx-auto px-4 sm:px-6 flex items-center justify-between">
          <div
            className="flex items-center gap-3 overflow-hidden cursor-pointer flex-1"
            onClick={() => setIsNavOpen(!isNavOpen)}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors shrink-0 ${isNavOpen ? "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300" : "bg-transparent text-slate-400 dark:text-slate-500"}`}
            >
              {isNavOpen ? (
                <ChevronUpIcon className="w-5 h-5" />
              ) : (
                <ChevronDownIcon className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0 flex flex-col justify-center">
              <h1 className="text-sm font-black text-slate-800 dark:text-white tracking-tight truncate max-w-[150px] sm:max-w-xs">
                {activeExam.config.subject}
              </h1>
              <p className="text-[10px] font-medium text-slate-400 dark:text-slate-500 font-mono tracking-wide truncate">
                {isNavOpen ? "Ketuk untuk tutup" : "Ketuk untuk navigasi"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Compact Monitoring Badge - Visible ONLY when Nav is Closed */}
            {isMonitoring && !isNavOpen && (
              <div className="flex items-center gap-1.5 px-2 py-1.5 bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800 rounded-lg mr-1 animate-fade-in">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </span>
                <span className="hidden sm:inline text-[10px] font-black uppercase tracking-wide text-indigo-600 dark:text-indigo-400 whitespace-nowrap">
                  {monitoringLabel}
                </span>
              </div>
            )}

            {toggleTheme && (
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all shadow-sm border border-slate-200 dark:border-slate-700"
                aria-label="Toggle Theme"
              >
                {isDarkMode ? (
                  <SunIcon className="w-4 h-4" />
                ) : (
                  <MoonIcon className="w-4 h-4" />
                )}
              </button>
            )}
            <div
              className={`flex items-center gap-2 px-3 py-2 rounded-xl border font-mono font-bold tracking-tight transition-all shadow-sm ${timeLeft < 300 ? "bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 border-rose-100 dark:border-rose-900 animate-pulse" : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700"}`}
            >
              <ClockIcon className="w-4 h-4" />
              <span className="text-sm">{formatTime(timeLeft)}</span>
            </div>
          </div>
        </div>
      </header>

      <div
        className={`fixed top-16 left-0 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl z-50 border-b border-slate-200 dark:border-slate-800 shadow-xl transition-all duration-300 ease-in-out origin-top ${isNavOpen ? "translate-y-0 opacity-100 visible" : "-translate-y-full opacity-0 invisible"}`}
      >
        <div className="w-full max-w-full mx-auto p-4 sm:p-6 max-h-[70vh] overflow-y-auto">
          <div className="flex flex-wrap gap-2 justify-center">
            {activeExam.questions.map((q, idx) => {
              if (q.questionType === "INFO") return null;
              const num =
                activeExam.questions
                  .slice(0, idx)
                  .filter((i) => i.questionType !== "INFO").length + 1;
              const answered = isAnswered(q, answers);
              return (
                <button
                  key={q.id}
                  onClick={() => scrollToQuestion(q.id)}
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-lg border flex items-center justify-center text-xs font-bold transition-all ${answered ? "bg-indigo-600 border-indigo-600 text-white" : hasAttemptedSubmit ? "bg-rose-50 border-rose-300 text-rose-600 animate-pulse" : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"}`}
                >
                  {num}
                </button>
              );
            })}
          </div>

          {/* Monitoring Explanation in Dropdown (Visible when Nav Open) */}
          {isMonitoring && (
            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col items-center text-center animate-fade-in">
              <div className="bg-indigo-50 dark:bg-indigo-900/20 px-4 py-2 rounded-full border border-indigo-100 dark:border-indigo-800 flex items-center gap-2 mb-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
                </span>
                <span className="text-xs font-black uppercase tracking-widest text-indigo-700 dark:text-indigo-300">
                  {monitoringLabel}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 max-w-md font-medium leading-relaxed">
                {activeExam.config.continueWithPermission
                  ? "Sistem memantau aktivitas Anda. Jika Anda keluar dari aplikasi atau mencoba melakukan kecurangan, ujian akan otomatis terkunci dan memerlukan token guru untuk melanjutkan."
                  : "Sistem memantau aktivitas Anda selama pengerjaan ujian. Setiap upaya meninggalkan halaman akan tercatat dalam log aktivitas yang dapat dilihat oleh pengawas."}
              </p>
            </div>
          )}
        </div>
      </div>

      <main className="w-full max-w-full mx-auto px-4 sm:px-6 pt-24 space-y-8">
        {activeExam.questions.map((q, idx) => {
          const num =
            activeExam.questions
              .slice(0, idx)
              .filter((i) => i.questionType !== "INFO").length + 1;
          const answered = isAnswered(q, answers);
          const isMissing =
            hasAttemptedSubmit && !answered && q.questionType !== "INFO";

          return (
            <div
              key={q.id}
              id={q.id}
              className={`scroll-mt-32 animate-fade-in transition-all duration-500 ${isMissing ? "ring-2 ring-rose-400 rounded-[1.5rem]" : ""}`}
            >
              <div className="bg-white dark:bg-slate-900 rounded-[1.5rem] border border-slate-100 dark:border-slate-800 shadow-sm p-6 sm:p-8">
                <div className="flex gap-5">
                  <div className="shrink-0">
                    <span
                      className={`text-sm font-black w-8 h-8 flex items-center justify-center rounded-xl transition-all shadow-sm ${isMissing ? "bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400" : answered ? "text-white bg-indigo-600 dark:bg-indigo-500 shadow-indigo-200 dark:shadow-none" : "text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800"}`}
                    >
                      {q.questionType === "INFO" ? "i" : num}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    {q.audioUrl && (
                      <div className="mb-4">
                        <AudioPlayer src={q.audioUrl} />
                      </div>
                    )}
                    <div className="prose prose-slate dark:prose-invert max-w-none font-medium leading-relaxed mb-6">
                      {renderQuestionTextWithChart(
                        q.questionText,
                        q.chartData,
                        optimizeHtml,
                      )}
                    </div>

                    <div className="space-y-4">
                      {(q.questionType === "MULTIPLE_CHOICE" ||
                        q.questionType === "COMPLEX_MULTIPLE_CHOICE") && (
                        <MultipleChoiceView
                          question={q}
                          answers={answers}
                          onAnswerChange={handleAnswerChange}
                          optimizeHtml={optimizeHtml}
                        />
                      )}

                      {q.questionType === "TRUE_FALSE" && (
                        <TrueFalseView
                          question={q}
                          answers={answers}
                          onAnswerChange={handleAnswerChange}
                          optimizeHtml={optimizeHtml}
                        />
                      )}

                      {q.questionType === "MATCHING" && (
                        <MatchingView
                          question={q}
                          answers={answers}
                          rightOptions={matchingOptionsMap[q.id] || []}
                          onAnswerChange={handleAnswerChange}
                          optimizeHtml={optimizeHtml}
                        />
                      )}

                      {q.questionType === "ESSAY" && (
                        <textarea
                          value={answers[q.id] || ""}
                          onChange={(e) =>
                            handleAnswerChange(q.id, e.target.value)
                          }
                          className="w-full p-5 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:border-indigo-500 dark:focus:border-indigo-500 outline-none min-h-[160px] text-sm text-slate-700 dark:text-slate-200 transition-all resize-y placeholder:text-slate-400 dark:placeholder:text-slate-600"
                          placeholder="Tulis jawaban lengkap Anda..."
                        />
                      )}

                      {q.questionType === "FILL_IN_THE_BLANK" && (
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <PencilIcon className="w-5 h-5 text-slate-400" />
                          </div>
                          <input
                            type="text"
                            value={answers[q.id] || ""}
                            onChange={(e) =>
                              handleAnswerChange(q.id, e.target.value)
                            }
                            className="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-xl focus:bg-white dark:focus:bg-slate-900 focus:border-indigo-500 dark:focus:border-indigo-500 outline-none text-sm font-bold text-slate-800 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600 transition-all"
                            placeholder="Ketik jawaban singkat..."
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </main>

      <div className="fixed bottom-8 inset-x-0 flex justify-center z-50 px-4 pointer-events-none">
        <div className="bg-white dark:bg-slate-900 p-2 rounded-[1.2rem] shadow-2xl border border-white dark:border-slate-800 ring-1 ring-slate-100 dark:ring-slate-800 pointer-events-auto flex items-center gap-4 transition-transform hover:scale-105">
          <div className="pl-4 flex flex-col justify-center">
            <span className="hidden sm:inline text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase">
              Progres
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-black text-slate-800 dark:text-white">
                {answeredCount}
              </span>
              <span className="text-xs font-bold text-slate-400 dark:text-slate-500">
                / {totalQuestions}
              </span>
            </div>
          </div>
          <button
            onClick={() => handleSubmit(false)}
            disabled={isSubmitting}
            className="bg-slate-900 dark:bg-indigo-600 text-white pl-6 pr-6 py-3 rounded-xl font-bold text-xs hover:bg-indigo-600 dark:hover:bg-indigo-700 transition-all flex items-center gap-2 shadow-lg active:scale-95 disabled:opacity-70"
          >
            <span>{isSubmitting ? "Mengirim..." : "Selesai"}</span>
            <CheckCircleIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
