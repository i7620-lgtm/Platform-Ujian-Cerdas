const str = `["0,5","50%"," \n2\n4\n42​ \n"]`;
try {
    console.log("Parsing:", JSON.parse(str));
} catch (e) {
    console.log("Failed:", e.message);
}
