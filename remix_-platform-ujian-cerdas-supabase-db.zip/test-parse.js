const parseList = (str) => {
    if (!str) return [];
    
    const deepParse = (input) => {
        try {
            let fixedInput = input;
            try {
                JSON.parse(fixedInput);
            } catch (e) {
                fixedInput = input.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t");
            }
            const parsed = JSON.parse(fixedInput);
            if (typeof parsed === 'string') {
                return deepParse(parsed);
            }
            return parsed;
        } catch (e) {
            let cleaned = input.trim();
            if (cleaned.startsWith('[') && !cleaned.endsWith(']')) cleaned = cleaned.slice(1);
            if (cleaned.endsWith(']') && !cleaned.startsWith('[')) cleaned = cleaned.slice(0, -1);
            if (cleaned.startsWith('"') && cleaned.endsWith('"')) cleaned = cleaned.slice(1, -1);
            cleaned = cleaned.replace(/\\"/g, '"');
            return cleaned;
        }
    };

    try {
        const parsed = deepParse(str);
        if (Array.isArray(parsed)) {
            const flattened = [];
            const processItem = (item) => {
                if (typeof item === 'string') {
                    if ((item.startsWith('[') && item.endsWith(']')) || (item.startsWith('{') && item.endsWith('}'))) {
                        try {
                            const unescaped = deepParse(item);
                            if (Array.isArray(unescaped)) {
                                unescaped.forEach(processItem);
                            } else {
                                flattened.push(String(unescaped));
                            }
                        } catch {
                            flattened.push(String(item));
                        }
                    } else {
                        flattened.push(String(item));
                    }
                } else if (Array.isArray(item)) {
                    item.forEach(processItem);
                } else {
                    flattened.push(String(item));
                }
            };
            parsed.forEach(processItem);
            return flattened;
        }
    } catch (e) { console.error(e); }
    
    if (str.includes('<') && str.includes('>')) {
        return [str.trim()];
    }
    
    let cleanStr = str.trim();
    if (cleanStr.startsWith('[') && cleanStr.endsWith(']')) {
        cleanStr = cleanStr.slice(1, -1);
    }
    
    return cleanStr.split(',').map(s => {
        let trimmed = s.trim();
        if (trimmed.startsWith('"') && trimmed.endsWith('"')) {
            trimmed = trimmed.slice(1, -1);
        }
        trimmed = trimmed.replace(/\\"/g, '"');
        return trimmed;
    }).filter(s => s !== '');
};

const badStr = `["[\\"[\\\\\\"0\\"","\\"5\\\\\\"\\"","\\"\\\\\\"50%\\\\\\"\\"","\\"\\\\\\" \\n2\\n4\\n42​ \\n\\\\\\"]\\"","\\"0","5\\"","\\"50%\\"","\\" \\n2\\n4\\n42​ \\n\\"]","0,5","50%"," \\n2\\n4\\n42​ \\n"]`;
console.log("Parsed:", parseList(badStr));
