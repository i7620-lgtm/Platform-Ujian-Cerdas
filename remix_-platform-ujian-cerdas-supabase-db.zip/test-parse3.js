const arr = [" \n2\n4\n42​ \n"];
const str = JSON.stringify(arr);
console.log("Stringified:", str);
try {
    console.log("Parsed:", JSON.parse(str));
} catch (e) {
    console.log("Failed:", e.message);
}
