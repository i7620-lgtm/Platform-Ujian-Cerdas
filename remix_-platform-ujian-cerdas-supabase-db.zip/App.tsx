import React, { useState, useCallback, useEffect, Suspense } from 'react';
import { StudentLogin } from './components/StudentLogin';
import { ExamWaitingRoom } from './components/student/ExamWaitingRoom';
import { StudentExamPage } from './components/StudentExamPage';
import { StudentResultPage } from './components/StudentResultPage';
import { ResultNotFoundPage } from './components/ResultNotFoundPage';
import { TeacherLogin } from './components/TeacherLogin';
import { OngoingExamModal } from './components/teacher/DashboardModals';
import type { Exam, Student, Result, TeacherProfile, ResultStatus } from './types';
import { LogoIcon, NoWifiIcon, UserIcon, ArrowLeftIcon, SunIcon, MoonIcon, QrCodeIcon, BookOpenIcon } from './components/Icons';
import { storageService } from './services/storage';
import { InvitationModal } from './components/teacher/InvitationModal';
import { ProfileCompletionModal } from './components/teacher/ProfileCompletionModal';
import { TermsPage, PrivacyPage } from './components/LegalPages';
import { TutorialPage } from './components/TutorialPage';
import { CollaboratorView } from './components/CollaboratorView';
import { supabase } from './lib/supabase';

// Lazy Load Teacher Dashboard agar siswa tidak perlu mendownload kodenya
const TeacherDashboard = React.lazy(() => import('./components/TeacherDashboard').then(module => ({ default: module.TeacherDashboard })));

type View = 'SELECTOR' | 'TEACHER_LOGIN' | 'STUDENT_LOGIN' | 'TEACHER_DASHBOARD' | 'STUDENT_EXAM' | 'STUDENT_RESULT' | 'LIVE_MONITOR' | 'TERMS' | 'PRIVACY' | 'TUTORIAL' | 'WAITING_ROOM' | 'COLLABORATOR_MODE' | 'RESULT_NOT_FOUND';

const App: React.FC = () => {
  const [view, setView] = useState<View>('SELECTOR');
  const [previousView, setPreviousView] = useState<View>('SELECTOR');
  const [currentExam, setCurrentExam] = useState<Exam | null>(null);
  const [waitingExam, setWaitingExam] = useState<Exam | null>(null);
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [studentResult, setStudentResult] = useState<Result | null>(null);
  const [resumedResult, setResumedResult] = useState<Result | null>(null);
  const [teacherProfile, setTeacherProfile] = useState<TeacherProfile | null>(null);
  const [showProfileCompletion, setShowProfileCompletion] = useState(false);
  const [exams, setExams] = useState<Record<string, Exam>>({});
  const [results, setResults] = useState<Result[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' && navigator.onLine !== undefined ? navigator.onLine : true);
  const [isLoadingSession, setIsLoadingSession] = useState(true);
  const [prefillCode, setPrefillCode] = useState<string>('');
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [collaboratorData, setCollaboratorData] = useState<{ exam: Exam, role: 'editor' | 'viewer', token: string } | null>(null);

  // Theme State Management
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
        try {
            const local = localStorage.getItem('theme');
            return local === 'dark' || (!local && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
        } catch {
            return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
    }
    return false;
  });

  // Apply Theme Effect
  useEffect(() => {
    if (darkMode) {
        document.documentElement.classList.add('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#0f172a');
        try { localStorage.setItem('theme', 'dark'); } catch { /* ignore */ }
    } else {
        document.documentElement.classList.remove('dark');
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', '#ffffff');
        try { localStorage.setItem('theme', 'light'); } catch { /* ignore */ }
    }
  }, [darkMode]);

  // Global Math Hydration Effect
  useEffect(() => {
    const renderMath = (el: Element) => {
      const latex = el.getAttribute('data-latex');
      if (latex && el.innerHTML.trim() === '') {
        const w = window as any;
        if (w.katex) {
            try {
                const displayMode = (el as HTMLElement).style.display === 'block';
                el.innerHTML = w.katex.renderToString(latex, { throwOnError: false, displayMode });
            } catch(e) { }
        }
      }
    };

    // Hydrate everything
    const hydrateAll = () => {
        document.querySelectorAll('.math-visual[data-latex]').forEach(renderMath);
    };

    // Initial check (maybe katex is already here)
    hydrateAll();

    // Polling mechanism to wait for window.katex to load
    const katexInterval = setInterval(() => {
        const w = window as any;
        if (w.katex) {
            clearInterval(katexInterval);
            hydrateAll(); // Guarantee we render existing equations
        }
    }, 500);

    // Observe changes for dynamic rendering
    const observer = new MutationObserver((mutations) => {
      let shouldRender = false;
      for (const m of mutations) {
        if (m.addedNodes.length > 0) {
            shouldRender = true;
            break;
        }
      }
      if (shouldRender) {
        hydrateAll();
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    
    return () => {
        observer.disconnect();
        clearInterval(katexInterval);
    };
  }, []);

  const toggleTheme = () => setDarkMode(!darkMode);

  const isProfileComplete = (profile: TeacherProfile) => {
    return !!(profile.fullName && profile.school && profile.regency && 
           profile.fullName !== 'Pengguna' && profile.school !== '-' && profile.regency !== '-');
  };

  useEffect(() => {
    const checkSession = async () => {
        try {
            const profile = await storageService.getCurrentUser();
            if (profile) {
                setTeacherProfile(profile);
                if (!isProfileComplete(profile)) {
                    setShowProfileCompletion(true);
                }
                setView('TEACHER_DASHBOARD');
            }
        } catch (e) {
            console.error("Session check failed", e);
        } finally {
            setIsLoadingSession(false);
        }
    };
    checkSession();
  }, []);

  useEffect(() => {
    // HARD BLOCK: Ensure Realtime is ONLY enabled if disableRealtime is explicitly false.
    // This prevents students in "Normal Mode" from consuming Realtime Concurrent Peak Connections.
    const isRealtimeEnabled = currentExam?.config?.disableRealtime === false;
    
    if ((view === 'STUDENT_EXAM' || view === 'STUDENT_RESULT') && currentStudent && currentStudent.resultId && currentStudent.class !== 'PREVIEW' && currentExam && isRealtimeEnabled) {
      const channel = supabase.channel(`student-result-${currentStudent.resultId}`)
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'results', filter: `id=eq.${currentStudent.resultId}` }, async (payload) => {
            const newStudentName = payload.new.student_name;
            const newClassName = payload.new.class_name;
            const newStudentId = payload.new.student_id;
            
            if (newStudentName && newClassName && newStudentId) {
                const [schoolName, className] = newClassName.includes('::') ? newClassName.split('::') : ['', newClassName];
                const absentNumber = newStudentId.match(/%([^%]+)$/)?.[1] || '';

                setCurrentStudent(prev => {
                    if (!prev) return null;
                    
                    // Update localStorage so next login uses the updated data
                    try {
                        const examCode = currentExam?.code;
                        if (examCode) {
                            const prefData = {
                                fullName: newStudentName.trim(),
                                schoolName: schoolName.trim(),
                                studentClass: className.trim(),
                                absentNumber: absentNumber.trim()
                            };
                            localStorage.setItem(`student_pref_${examCode}`, JSON.stringify(prefData));
                        }

                        localStorage.setItem('saved_student_fullname', newStudentName.trim());
                        localStorage.setItem('saved_student_class', className.trim());
                        localStorage.setItem('saved_student_absent', absentNumber.trim());
                        if (schoolName) localStorage.setItem('saved_student_school', schoolName.trim());
                    } catch { /* ignore */ }

                    return {
                        ...prev,
                        fullName: newStudentName,
                        class: className,
                        schoolName: schoolName,
                        absentNumber: absentNumber,
                        studentId: newStudentId
                    };
                });
                
                // Update studentResult if it exists
                setStudentResult(prev => {
                    if (!prev) return null;
                    return {
                        ...prev,
                        student: {
                            ...prev.student,
                            fullName: newStudentName,
                            class: className,
                            schoolName: schoolName,
                            absentNumber: absentNumber,
                            studentId: newStudentId
                        }
                    };
                });
            }
        })
        .subscribe();
      return () => { supabase.removeChannel(channel); };
    }
  }, [view, currentStudent, currentExam]);

  const handleStudentLoginSuccess = useCallback(async (examCode: string, student: Student, isPreview: boolean = false) => {
    setIsSyncing(true);
    try {
      // Pass studentId to ensure consistent shuffling (Fix #2)
      const exam = await storageService.getExamForStudent(examCode, student.studentId, isPreview);
      if (!exam) { 
        alert("Kode Ujian tidak ditemukan atau belum dipublikasikan."); 
        return; 
      }

      // FIX: Check schedule before allowing entry (Manual Login)
      if (!isPreview) {
          const mode = exam.config.examMode || 'UJIAN';
          
          if (mode === 'UJIAN') {
              const dateStr = exam.config.startDate || exam.config.date;
              let startTime: Date;
              if (dateStr.includes('T') && dateStr.length > 10) {
                  startTime = new Date(dateStr);
              } else {
                  startTime = new Date(`${dateStr}T${exam.config.startTime || '00:00'}`);
              }
              
              const now = new Date();

              if (!isNaN(startTime.getTime()) && now < startTime) {
                  setWaitingExam(exam);
                  setCurrentStudent(student);
                  setView('WAITING_ROOM');
                  return;
              }
          }
      }
      
      const res = await storageService.getStudentResult(examCode, student.studentId);
      
      if (res && res.status === 'completed' && !isPreview) {
          if (!exam.config.allowRetakes) {
              setCurrentExam(exam);
              setCurrentStudent({ ...student, resultId: res.id });
              setStudentResult(res);
              setView('STUDENT_RESULT');
              return;
          }
      }

      if (res && res.status === 'force_closed' && !isPreview) {
          setCurrentExam(exam);
          setCurrentStudent({ ...student, resultId: res.id });
          setStudentResult(res);
          setView('STUDENT_RESULT');
          return;
      }

      // Initialize with potential resultId if resuming
      let studentWithId = { ...student, resultId: res?.id };
      
      if (res && res.status === 'in_progress' && !isPreview) {
        setResumedResult(res);
        studentWithId = { ...student, resultId: res.id };
      } else if (!isPreview) {
        // Initial creation
        const newRes = await storageService.submitExamResult({
          student,
          examCode,
          answers: { _startTime: Date.now().toString() },
          score: 0,
          totalQuestions: exam.questions.length,
          correctAnswers: 0,
          status: 'in_progress',
          timestamp: Date.now()
        });
        // Capture the new ID
        studentWithId = { ...student, resultId: newRes.id as number };
        setResumedResult(newRes as unknown as Result);
      }
      
      setCurrentExam(exam);
      setCurrentStudent(studentWithId);
      setView('STUDENT_EXAM');
    } catch (err: unknown) {
        const error = err as Error;
        if (error.message === 'EXAM_IS_DRAFT') {
            alert("Ujian ini masih berupa draf.");
        } else {
            console.error(error);
            alert("Gagal memuat ujian. Periksa koneksi internet Anda.");
        }
    } finally { setIsSyncing(false); }
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pathname = window.location.pathname;

    // RESULT PAGE DIRECT LINK CHECK (/result/:examCode/:studentId)
    if (pathname.startsWith('/result/')) {
        const parts = pathname.split('/');
        if (parts.length >= 4) {
            const examCode = parts[2].trim().toUpperCase();
            let studentId = decodeURIComponent(parts[3]);
            if (window.location.hash) {
                studentId += decodeURIComponent(window.location.hash);
            }
            
            setIsSyncing(true);
            storageService.getExamForStudent(examCode, studentId, true)
                .then(async (exam) => {
                    if (exam) {
                        const res = await storageService.getStudentResult(examCode, studentId);
                        if (res) {
                            setCurrentExam(exam);
                            setStudentResult(res);
                            setView('STUDENT_RESULT');
                        } else {
                            setView('RESULT_NOT_FOUND');
                            window.history.replaceState({}, '', '/');
                        }
                    } else {
                        setView('RESULT_NOT_FOUND');
                        window.history.replaceState({}, '', '/');
                    }
                })
                .catch(e => {
                    console.error(e);
                    setView('RESULT_NOT_FOUND');
                    window.history.replaceState({}, '', '/');
                })
                .finally(() => setIsSyncing(false));
            return;
        }
    }
    
    // COLLABORATOR CHECK
    const collabCode = params.get('collab_code');
    const collabToken = params.get('collab_token');
    
    if (collabCode && collabToken) {
        setIsSyncing(true);
        storageService.getExamByCollaboratorToken(collabCode, collabToken)
            .then(data => {
                if (data) {
                    setCollaboratorData({ ...data, token: collabToken });
                    setView('COLLABORATOR_MODE');
                    window.history.replaceState({}, document.title, window.location.pathname);
                } else {
                    alert("Link kolaborator tidak valid atau kadaluarsa.");
                    window.history.replaceState({}, '', '/');
                }
            })
            .catch(e => {
                console.error(e);
                alert("Gagal memuat sesi kolaborator.");
                window.history.replaceState({}, '', '/');
            })
            .finally(() => setIsSyncing(false));
        return;
    }

    const previewCode = params.get('preview');
    if (previewCode) {
        const dummyStudent: Student = {
            fullName: 'Mode Pratinjau',
            class: 'PREVIEW',
            absentNumber: '00',
            // Format ID Konsisten: Nama-Kelas-Absen
            studentId: `Mode Pratinjau-PREVIEW-00-${Date.now()}`
        };
        handleStudentLoginSuccess(previewCode.trim().toUpperCase(), dummyStudent, true);
        window.history.replaceState({}, document.title, window.location.pathname);
        return;
    }

    const joinCode = params.get('join');
    if (joinCode) {
        const code = joinCode.trim().toUpperCase();
        // Check schedule before showing login
        storageService.getExamForStudent(code, 'check_schedule', true)
            .then(exam => {
                if (exam) {
                    const mode = exam.config.examMode || 'UJIAN';
                    
                    if (mode === 'UJIAN') {
                        const dateStr = exam.config.startDate || exam.config.date;
                        
                        let startTime: Date;
                        if (dateStr.includes('T') && dateStr.length > 10) {
                            startTime = new Date(dateStr);
                        } else {
                            startTime = new Date(`${dateStr}T${exam.config.startTime || '00:00'}`);
                        }
                        
                        const now = new Date();

                        // Strict check: Only go to waiting room if startTime is valid AND now < startTime
                        if (!isNaN(startTime.getTime()) && now < startTime) {
                            // Too early (Waiting Room)
                            setWaitingExam(exam);
                            setView('WAITING_ROOM');
                        } else {
                            // On time (Direct Login)
                            setPrefillCode(code);
                            setView('STUDENT_LOGIN');
                        }
                    } else {
                        // PR Mode: Direct Login
                        setPrefillCode(code);
                        setView('STUDENT_LOGIN');
                    }
                } else {
                    setPrefillCode(code);
                    setView('STUDENT_LOGIN');
                }
            })
            .catch(() => {
                // Fallback on error (Network or Not Found)
                // Still prefill to let user try manually or see error in login form
                setPrefillCode(code);
                setView('STUDENT_LOGIN');
            });
            
        window.history.replaceState({}, document.title, window.location.pathname);
        return;
    }

    const liveCode = params.get('live');
    if (liveCode) {
        setIsSyncing(true);
        // Live monitor doesn't need student specific shuffling, pass generic ID or empty
        storageService.getExamForStudent(liveCode.trim().toUpperCase(), 'monitor', true)
            .then(exam => {
                if (exam && exam.config.enablePublicStream) {
                    setCurrentExam(exam);
                    setView('LIVE_MONITOR');
                } else {
                    alert("Akses Pantauan Ditolak.");
                    window.history.replaceState({}, '', '/');
                }
            })
            .catch(() => {
                alert("Gagal memuat data ujian.");
                window.history.replaceState({}, '', '/');
            })
            .finally(() => setIsSyncing(false));
    }
  }, [handleStudentLoginSuccess]);

  useEffect(() => {
    const handleOnline = () => { setIsOnline(true); storageService.syncData(); };
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const refreshExams = useCallback(async () => {
    if (!teacherProfile) return;
    setIsSyncing(true);
    try {
        const examMap = await storageService.getExams(teacherProfile);
        setExams(examMap);
    } finally { setIsSyncing(false); }
  }, [teacherProfile]);

  const refreshResults = useCallback(async () => {
    if (!teacherProfile) return;
    setIsSyncing(true);
    try {
        const data = await storageService.getResults();
        setResults(data);
    } finally { setIsSyncing(false); }
  }, [teacherProfile]);

  const handleExamSubmit = async (answers: Record<string, string>, timeLeft: number, status: ResultStatus = 'completed', activityLog: string[] = [], location?: string, grading?: unknown) => {
    if (!currentExam || !currentStudent) return;
    
    if (currentStudent.class === 'PREVIEW') {
        alert("Mode Pratinjau selesai.");
        resetToHome();
        return;
    }

    if (status === 'completed' || status === 'force_closed') setIsSyncing(true);
    
    // Add additional safety to ensure duration is populated
    const finalAnswers = { ...answers };
    if ((status === 'completed' || status === 'force_closed') && finalAnswers['_startTime']) {
         const startTime = parseInt(finalAnswers['_startTime']);
         if (!isNaN(startTime)) {
              const seconds = Math.floor((Date.now() - startTime) / 1000);
              finalAnswers['_duration'] = Math.max(0, seconds).toString();
         }
    }

    const res = await storageService.submitExamResult({
        student: currentStudent,
        examCode: currentExam.code,
        answers: finalAnswers,
        score: (grading as {score?: number})?.score || 0,
        totalQuestions: (grading as {totalQuestions?: number})?.totalQuestions || currentExam.questions.length,
        correctAnswers: (grading as {correctAnswers?: number})?.correctAnswers || 0,
        status, 
        activityLog, 
        location, 
        timestamp: Date.now()
    });
    
    if (status === 'completed' || status === 'force_closed') {
        // RE-FETCH EXAM: Ensure we have the full exam with answers if showResultToStudent is true
        // This is necessary because the initial fetch at login might have stripped answers
        const updatedExam = await storageService.getExamForStudent(currentExam.code, currentStudent.studentId, false);
        if (updatedExam) setCurrentExam(updatedExam);
        
        setStudentResult(res as unknown as Result);
        setView('STUDENT_RESULT');
        setIsSyncing(false);
    }
  };

  const handleResumeFromLock = () => {
      if (studentResult) {
          const unlockedResult = { ...studentResult, status: 'in_progress' } as Result;
          setStudentResult(unlockedResult);
          setResumedResult(unlockedResult);
          setView('STUDENT_EXAM');
      }
  };

  const resetToHome = () => { 
    setView('SELECTOR'); 
    setCurrentExam(null); 
    setWaitingExam(null);
    setCurrentStudent(null); 
    setStudentResult(null); 
    setResumedResult(null);
    setTeacherProfile(null);
    setPrefillCode('');
    setCollaboratorData(null);
    // FIX: Clear shared state to prevent data leakage/ghosting between sessions
    setExams({});
    setResults([]);
    window.history.replaceState({}, '', '/');
  };

  const handleLogout = async () => {
    // Immediate state clear to prevent flash
    resetToHome();
    try {
        await storageService.signOut();
    } catch(e) {
        console.error("Sign out error", e);
    }
  };

  // Loading Fallback Component for Suspense
  const DashboardLoader = () => (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#F8FAFC] dark:bg-slate-900">
        <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Memuat Dashboard...</p>
    </div>
  );

  if (isLoadingSession) {
    return (
        <div className="min-h-screen flex items-center justify-center bg-[#FAFAFA] dark:bg-slate-950">
            <div className="flex flex-col items-center gap-4">
                <div className="w-10 h-10 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                <p className="text-sm font-medium text-slate-500">Memuat sesi...</p>
            </div>
        </div>
    );
  }

  // Common Theme Toggle Button
  const ThemeToggle = ({ className = "" }: { className?: string }) => (
    <button 
        onClick={toggleTheme} 
        className={`p-2.5 rounded-full bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 transition-all shadow-md dark:shadow-none border border-slate-100 dark:border-slate-700 ${className}`}
        title={darkMode ? 'Mode Terang' : 'Mode Gelap'}
        aria-label="Toggle Theme"
    >
        {darkMode ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
    </button>
  );

  return (
    <div className="min-h-screen bg-[#FAFAFA] dark:bg-slate-950 text-slate-800 dark:text-slate-100 font-sans selection:bg-indigo-100 selection:text-indigo-800 overflow-x-hidden antialiased flex flex-col transition-colors duration-300">
        
        {/* Status Jaringan Minimalis & Elegan */}
        <div className="fixed top-6 right-6 z-[100] pointer-events-none flex flex-col gap-2 items-end">
            {/* Theme Toggle in Top Right for Selector View */}
            {view === 'SELECTOR' && (
                <div className="pointer-events-auto mb-2">
                    <ThemeToggle />
                </div>
            )}

            {!isOnline && (
                <div className="bg-rose-500/90 backdrop-blur-md text-white px-4 py-2 rounded-full text-[11px] font-bold uppercase tracking-wide shadow-xl flex items-center gap-2 animate-bounce pointer-events-auto ring-1 ring-white/20">
                    <NoWifiIcon className="w-3.5 h-3.5"/> 
                    <span>Offline Mode</span>
                </div>
            )}
            
            {isSyncing && isOnline && (
                <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md text-indigo-600 dark:text-indigo-400 px-4 py-2 rounded-full text-[11px] font-bold uppercase tracking-wide shadow-lg border border-indigo-50 dark:border-slate-700 flex items-center gap-2 pointer-events-auto">
                    <div className="w-3 h-3 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                    <span>Menyimpan...</span>
                </div>
            )}
        </div>

        {/* Invite Button for Selector View (Redesigned) */}
        {view === 'SELECTOR' && (
            <div className="fixed top-6 left-6 z-[100]">
                <button
                    onClick={() => setIsInviteOpen(true)}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white/90 dark:bg-slate-800/90 text-slate-600 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-white dark:hover:bg-slate-800 transition-all shadow-lg shadow-slate-200/50 dark:shadow-none border border-slate-200/60 dark:border-slate-700 backdrop-blur-sm group"
                    title="Bagikan Aplikasi"
                >
                    <QrCodeIcon className="w-4 h-4 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-bold uppercase tracking-wider">Bagikan App</span>
                </button>
            </div>
        )}
        
        {view === 'SELECTOR' && (
            <div className="flex-1 flex flex-col p-6 relative overflow-y-auto">
                {/* Background Decor */}
                <div className="fixed inset-0 z-0 opacity-40 overflow-hidden pointer-events-none">
                    <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-100 dark:bg-slate-800 blur-[100px]"></div>
                    <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-50 dark:bg-slate-800 blur-[100px]"></div>
                </div>
                
                <div className="w-full max-w-sm z-10 animate-gentle-slide mx-auto my-auto">
                    <div className="text-center mb-10">
                        <div className="inline-flex p-4 bg-white dark:bg-slate-800 rounded-2xl shadow-sm mb-6 border border-slate-50 dark:border-slate-700 ring-1 ring-slate-100 dark:ring-slate-800">
                            <LogoIcon className="w-10 h-10 text-indigo-600 dark:text-indigo-400" />
                        </div>
                        
                        <h1 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight mb-3">UjianCerdas</h1>
                        <p className="text-slate-500 dark:text-slate-400 text-sm font-medium leading-relaxed">
                            Platform evaluasi modern.<br/>Ringan, Cepat, Terpercaya.
                        </p>
                    </div>
                    
                    <div className="space-y-4">
                        <button 
                            onClick={() => setView('STUDENT_LOGIN')} 
                            className="w-full group relative overflow-hidden bg-slate-900 dark:bg-indigo-600 text-white p-4 rounded-xl shadow-lg shadow-slate-200 dark:shadow-none transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
                        >
                            <div className="relative z-10 flex items-center justify-center gap-3">
                                <span className="font-bold text-sm tracking-wide">Masuk sebagai Siswa</span>
                                <ArrowLeftIcon className="w-4 h-4 rotate-180 group-hover:translate-x-1 transition-transform opacity-70" />
                            </div>
                        </button>

                        <button 
                            onClick={() => setView('TEACHER_LOGIN')} 
                            className="w-full flex items-center justify-center gap-2 p-4 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-xl border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-all duration-300 font-bold text-sm shadow-sm hover:shadow-md active:scale-[0.98]"
                        >
                            <UserIcon className="w-4 h-4" />
                            Area Pengajar
                        </button>

                        <button 
                            onClick={() => setView('TUTORIAL')} 
                            className="w-full flex items-center justify-center gap-2 p-4 bg-teal-50 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300 rounded-xl border border-teal-100 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900/50 transition-all duration-300 font-bold text-sm shadow-sm hover:shadow-md active:scale-[0.98]"
                        >
                            <BookOpenIcon className="w-4 h-4" />
                            Panduan & Fitur
                        </button>
                    </div>

                    <p className="mt-12 text-center text-[10px] font-bold text-slate-300 dark:text-slate-600 uppercase tracking-widest">
                        Versi 3.0.1 • Hemat Data
                    </p>
                </div>
            </div>
        )}

        {view === 'TEACHER_LOGIN' && (
            <TeacherLogin 
                onLoginSuccess={(p) => { 
                    setTeacherProfile(p); 
                    if (!isProfileComplete(p)) {
                        setShowProfileCompletion(true);
                    }
                    setView('TEACHER_DASHBOARD'); 
                }} 
                onBack={() => setView('SELECTOR')}
                onViewTerms={() => { setPreviousView('TEACHER_LOGIN'); setView('TERMS'); }}
                onViewPrivacy={() => { setPreviousView('TEACHER_LOGIN'); setView('PRIVACY'); }}
                isDarkMode={darkMode}
                toggleTheme={toggleTheme}
            />
        )}
        
        {view === 'STUDENT_LOGIN' && (
            <StudentLogin 
                onLoginSuccess={handleStudentLoginSuccess} 
                onBack={() => setView('SELECTOR')} 
                isDarkMode={darkMode}
                toggleTheme={toggleTheme}
                initialCode={prefillCode}
            />
        )}
        
        {view === 'TEACHER_DASHBOARD' && teacherProfile && (
            <Suspense fallback={<DashboardLoader />}>
                <TeacherDashboard 
                    key={teacherProfile.id} /* FIX: Force remount to prevent ghosting */
                    teacherProfile={teacherProfile} 
                    exams={exams} 
                    results={results}
                    isDarkMode={darkMode}
                    toggleTheme={toggleTheme}
                    addExam={async (e) => { 
                        const examWithAuthor = { ...e, authorId: teacherProfile.id, authorSchool: teacherProfile.school };
                        await storageService.saveExam(examWithAuthor); 
                        refreshExams(); 
                    }}
                    updateExam={async (e) => { 
                        const examWithAuthor = { ...e, authorId: teacherProfile.id, authorSchool: teacherProfile.school };
                        await storageService.saveExam(examWithAuthor); 
                        refreshExams(); 
                    }}
                    deleteExam={async (c) => { await storageService.deleteExam(c); refreshExams(); }}
                    onLogout={handleLogout}
                    onRefreshExams={refreshExams}
                    onRefreshResults={refreshResults}

                />
            </Suspense>
        )}
        
        {view === 'STUDENT_EXAM' && currentExam && currentStudent && (
            <StudentExamPage 
                exam={currentExam} 
                student={currentStudent} 
                initialData={resumedResult}
                onSubmit={handleExamSubmit}
                isDarkMode={darkMode}
                toggleTheme={toggleTheme}
            />
        )}
        
        {view === 'RESULT_NOT_FOUND' && (
        <ResultNotFoundPage 
          onBack={() => setView('SELECTOR')}
        />
      )}

      {view === 'STUDENT_RESULT' && studentResult && currentExam && (
            <StudentResultPage 
                result={studentResult} 
                exam={currentExam} 
                onFinish={resetToHome} 
                onResume={handleResumeFromLock}
                isDarkMode={darkMode}
                toggleTheme={toggleTheme}
            />
        )}

        {view === 'LIVE_MONITOR' && currentExam && (
            <OngoingExamModal 
                exam={currentExam}
                onClose={resetToHome}
                isReadOnly={true}
            />
        )}

        {view === 'WAITING_ROOM' && waitingExam && (
            <ExamWaitingRoom 
                exam={waitingExam}
                student={currentStudent || { fullName: 'Siswa', schoolName: '', class: '', absentNumber: '', studentId: '' }}
                onBack={resetToHome}
                onStartExam={(code, stud) => handleStudentLoginSuccess(code, stud)}
                isDarkMode={darkMode}
            />
        )}

        {view === 'COLLABORATOR_MODE' && collaboratorData && (
            <CollaboratorView 
                exam={collaboratorData.exam}
                role={collaboratorData.role}
                token={collaboratorData.token}
                onExit={resetToHome}
                isDarkMode={darkMode}
                toggleTheme={toggleTheme}
            />
        )}

        {/* Global Invitation Modal */}
        <InvitationModal 
            isOpen={isInviteOpen} 
            onClose={() => setIsInviteOpen(false)} 
        />

        {/* Profile Completion Modal */}
        {showProfileCompletion && teacherProfile && (
            <ProfileCompletionModal 
                profile={teacherProfile}
                onComplete={(updated) => {
                    setTeacherProfile(updated);
                    setShowProfileCompletion(false);
                }}
            />
        )}

        {/* Legal Pages */}
        {view === 'TERMS' && (
            <TermsPage onBack={() => setView(previousView)} />
        )}

        {view === 'PRIVACY' && (
            <PrivacyPage onBack={() => setView(previousView)} />
        )}

        {/* Tutorial Page */}
        {view === 'TUTORIAL' && (
            <TutorialPage onBack={() => setView('SELECTOR')} />
        )}
    </div>
  );
};
 
export default App;