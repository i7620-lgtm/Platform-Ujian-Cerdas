import fs from 'fs';
const text = fs.readFileSync('./components/teacher/GeometryModal.tsx', 'utf8');
const lines = text.split('\n');
const start = lines.findIndex(l => l.includes('const extractNum = (val: any, defaultVal: number): number => {'));
const end = lines.findIndex(l => l.includes('export const GeometryModal: React.FC<GeometryModalProps> = ({ isOpen, onClose, onInsert }) => {'));
if (start !== -1 && end !== -1) {
    const newText = [...lines.slice(0, start), ...lines.slice(end)].join('\n');
    fs.writeFileSync('./components/teacher/GeometryModal.tsx', newText);
    console.log('Removed successfully.');
} else {
    console.log('Failed to find start or end', start, end);
}
